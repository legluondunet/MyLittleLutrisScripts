TOMB RAIDER:ATI patch
=====================
Requirements:

1.ATI card that utilizes the 3D Rage Pro chip type.  These cards include:

*All in Wonder Pro
*XPERT @ PLAY
*XPERT @ WORK

Also make sure you have the most current ATI drivers for your card.

http://www.atitech.com


2.You must be running the game in Windows '95.


To install the patch, copy all of the files from this directory into the directory
in which you installed the game (default = c:\tombraid\).

Run TOMBATI.EXE to begin the game.

HOTKEYS
=======
F2 = Frame rate display
F3 = Bilinear
F4 = Perspective (only for XPERT cards)

