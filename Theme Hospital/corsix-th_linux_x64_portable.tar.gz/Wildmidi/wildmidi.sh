#!/bin/bash


src=$1
dst=$2
format1=$3
cache=$4
x=0

cd $cache

for i in $src/*.$format1
do
LD_LIBRARY_PATH=libs ./wildmidi -c wildmidi.cfg "$i" -o $dst/$(basename $i .$format1).wav
echo "./wildmidi -c wildmidi.cfg "$i" -o $dst/$j.wav"
x=`expr $x + 1`	
done

echo source: $src
echo destination: $dst
echo format: $format1
echo cache: $cache
echo nombre de fichiers midi convertis en WAV: $x
