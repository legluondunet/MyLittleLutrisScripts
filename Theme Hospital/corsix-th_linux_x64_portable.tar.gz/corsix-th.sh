#!/bin/sh

if ! [ "$(ls -A Corsix-TH/music/)" ] && [ ! -d "Wildmidi" ]
then 
echo "le répertoire music est vide et pas de répertoire Wildmidi"
wget https://github.com/legluondunet/mlls-tools/raw/master/wildmidi/wildmidi.tar.xz
tar xvf wildmidi.tar.xz
rm -f -r wildmidi.tar.xz
fi

if ! [ "$(ls -A Corsix-TH/music/)" ]
then
echo "le répertoire music est vide"
cd Wildmidi
./wildmidi.sh ../TH/SOUND/MIDI ../Corsix-TH/music XMI .
cd ..
fi

if [ ! -f ~/.local/share/icons/corsix-th.png ]
then
echo "icônes non trouvées"
cd Corsix-TH
cp -R icons ~/.local/share/
cd ..
fi

gamepath="$PWD"
echo "le répertoire courant est $gamepath"
sed -i -e "s_Path=.*_Path="$gamepath/"_g" -e "s_Exec=.*_Exec="$gamepath"/corsix-th.sh_g" corsix-th.desktop

mkdir -p ~/.local/share/applications/
cp corsix-th.desktop ~/.local/share/applications/
chmod +x  ~/.local/share/applications/corsix-th.desktop

cd Corsix-TH
LD_LIBRARY_PATH=libs "./corsix-th" --interpreter="./CorsixTH.lua" $@
