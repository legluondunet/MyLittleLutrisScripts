#!/bin/sh

cp -R icons ~/.local/share/

gamepath="$PWD"
echo "le répertoire courant est $gamepath"
sed -i -e "s_Path=.*_Path="$gamepath/"_g" -e "s_Exec=.*_Exec="$gamepath"/corsix-th_g" corsix-th.desktop
cp corsix-th.desktop ~/.local/share/applications/


LD_LIBRARY_PATH=libs "./corsix-th" --interpreter="./CorsixTH.lua" $@
