SilentPatch - DDraw component for GTA III and GTA VC
Build 6
Last update - 25.10.2024


DESCRIPTION

	SilentPatch for the 3D-era Grand Theft Auto games is the first and flagship release of the "SilentPatch family",
	providing numerous fixes for this beloved franchise. SilentPatch addresses a wide range of issues,
	from critical fixes for crashes and other blockers to various major and minor improvements identified by
	the passionate community in these games over decades. SilentPatch does not alter the core gameplay experience,
	making it an optimal choice for both first-time players and the old guard returning for yet another playthrough.

	Featured fixes:

	CRITICAL FIXES
	Compatibility issues, crashes, progression blockers

	* DirectPlay dependency has been removed - this should improve compatibility with Windows 8 and newer
	* The game will not crash on startup if Data Execution Prevention is enabled for all applications anymore
	* "Cannot find enough available video memory" error showing on some computers has been resolved
	* Path to the User Files directory is now obtained differently, hopefully increasing compatibility and
	  future-proofing the games more

	OTHER FIXES
	All the remaining, non-critical fixes.

	* FILE_FLAG_NO_BUFFERING flag has been removed from IMG reading functions - speeding up streaming
	* Fixed an issue which would cause games to freeze if III/VC/SA were running at the same time

	ENHANCEMENTS
	Any changes that don't strictly fix game bugs

	* If the settings file is absent, the game will now default to your desktop resolution instead of 640x480x16
	* All censorships from German and French versions of the game have been removed


INSTALLATION

	Installation is easy as pie. Just extract the archive contents to your game directory and that's all!


SUPPORTED GAME VERSIONS

	* GTA III 1.0 (all versions)
	* GTA III 1.1 (all versions, including Steam version)
	* GTA VC 1.0 (all versions)
	* GTA VC 1.1 (all versions, including Steam version)


CREDITS

	SilentPatch includes code contributions from:

	aap
	B1ack_Wh1te
	DK22Pac
	Fire_Head
	Nick007J
	NTAuthority
	Sergeanur
	spaceeinstein
	Wesser


PATREON & GITHUB SPONSORS SUPPORTERS

	BuckoA51
	Calinou
	ddm
	deSSy2724
	Iman Shahani
	Jack
	kiwidog
	Lagahan
	m0b
	mirrorsedger
	MrNicolaZenk
	mrtaufner
	nta
	Phoenyx12
	retrozone.co
	SirJarko
	switchblade
	TJGM
	Vetle Ledaal


CONTACT

	zdanio95@gmail.com - e-mail
	cookieplmonster - Discord

Subscribe to my YouTube channel for more footage from my mods!
https://www.youtube.com/user/CookiePLMonster

Follow my Twitter account to be up to all my mod updates!
http://twitter.com/__silent_

Also take a look at my blog, featuring modding and programming related articles and more!
https://cookieplmonster.github.io/
