MotoRacer
Polygons version 3.22
____________________________________________________________________

This version should run faster on 4 Mb 3d accelerated graphic cards.

The 3.22 version correct the freezing problem that happens with 
	Voodoo 2 based cards.
____________________________________________________________________

Changes from the retail version

*) Hardware acceleration for graphic cards that do not support textured 
	polygons (like Matrox Millenium) is not available.

*) Your graphic card must have 4 Mb of memory to run the game with 
	hardware acceleration.

*) If the letters of the "enter your name screen" doesn't appear,
	try the -Alpha command line parameter.

*) If you get a message of not enough memory for textures, try 
	the -NoTextureSizeMax256 command line parameter.

*) To get more memory available for textures, you can try the -Pal16 switch.

*) If the game end suddenly or freeze the PC, try the -Alpha 
	command line parameter.

____________________________________________________________________

To install this patch, unzip all the files in a temp directory
and then run the UPDATE.EXE program.

The game MotoRacer must be installed before attempting to 
install the patch.

This patch can also be installed over the 3.20 patch.
____________________________________________________________________

July 98, the 9th
Delphine Software Int.