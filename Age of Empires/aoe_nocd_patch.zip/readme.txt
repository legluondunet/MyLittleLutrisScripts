================================================+
Title:		AOE CD Crack			|
Desc:		Age of Empires CD Crack		|
Date:		10.24.00			|
Author:		BioHazard			|
Email:		game-guru@usa.net		|
================================================+


-------------+
Installation |
-------------+
Unzip this file to any folder and run it. 


----------+
 Comments |
----------+
This crack supports all versions of AoE (1.0,1.0a,1.0b,1.0c).
I don't think ES'll come out with any more.

I have half this program ported over to assembly (masm32). If I finish,
6-12 more hours, the exe size would only shrink from 30KB to 10KB! 
Not worth it. So this is the final version of the crack.


-----------------+
 Troubleshooting |
-----------------+
This crack works fine. If you have any problems this is what you do.

1) Uninstall Age of Empires
2) Install Age of Empires
3) Run the 1.0a,1.0b, or 1.0c patch
4) Try the crack again

If it still doesn't work, email me with the error message you got.

