Widescreen Aspect Ratio Support for Need for Speed High Stakes
--------------------------------------------------------------
This patch fixes the aspect ratio in Need for Speed High Stakes when running on
a widescreen monitor. By default, the game always assumes a 4:3 aspect ratio and
as such, on a widescreen monitor the game accordingly appears horizontally
stretched.  With this patch, the game's graphics will be adjusted to match the
aspect ratio of the monitor (while interface elements will be left as-is),
thereby eliminating ridiculously wide cars and oval wheels.

It should work with all of the game's renderer; however, due to the many issues
with the game's default Direct3D 6 renderer as well as any common replacement
Direct3D 7 renderers, I strongly recommend using the game's Glide renderer
together with nGlide: http://www.zeus-software.com/downloads/nglide.

NOTE that this patch doesn't enable the game to run at actual widescreen
resolutions; the in-game resolution selection will still be limited to various
4:3 resolutions that your system supports. Instead, the patch queries your
desktop resolution (though this can be changed, see `Extra Configuration` below)
and then *assumes* that the 4:3 image that the game renders is at some point
stretched to fill your screen. With the D3D renderer, this upscaling will likely
be performed by your monitor or your graphics driver; with the voodoo2 renderer
and nGlide, nGlide will take care of the upscaling (and will do so in a truly
lossless fashion rather than just stretching out the pixel data). In short, if
you've currently set up the game to run in true 4:3 with black bars on a
widescreen monitor, simply installing this patch will make your game more
squashed because it is designed to assume that the game is set up to fill your
screen.

Installation
------------
- if you haven't already done so, use the game's 3D Setup utility to pick your
  preferred 3D renderer
- create a new directory `Drivers` in your NFSHS installation directory
- move the files `d3da.dll`, `softtria.dll` and `voodoo2a.dll` from the root of
  your NFSHS directory to the new `Drivers` subdirectory
- extract the contents of this archive into your NFSHS installation directory
- install the *Microsoft Visual C++ 2013 x86 Redistributable* (if you don't have
  it) using the included `vcredist_x86.exe` installer
- make sure the game is set to fill your screen rather than run in 4:3 with
  black bars at the sides:
  * with the Direct3D renderer, this is likely configured in your monitor's menu
    or your graphics driver settings
  * for voodoo2 and nGlide, set the screen resolution to 'By desktop' and aspect
    ratio to 'Fit to screen' or in the nGlide configurator
  * for another Glide wrapper, look for similar settings in its configuration
    dialog

To uninstall the patch, simply move the files from the `Drivers` directory back
into your NFSHS root directory, replacing the widescreen files.

Note: if you are using an updated 3D Setup utility that allows you to choose
between several Direct3D renderers, make sure not to use that feature after
installing the widescreen patch or the widescreen `d3da.dll` will get
overwritten with a different, unpatched one.

Known Issues
------------
- Split-screen might not get adjusted properly.
- Aspect ratio correction doesn't work if you decrease the window size in-game
  to less than maximum using the F11 and F12 keys.
- The "widescreening" effect is implemented by effectively stretching the image
  vertically, balancing the horizontal stretching of the wider screen. This
  stretching happens in a visually lossless fashion and properly ignores any
  2D interface elements, but it still means that compared to a 4:3 display, the
  top and lower parts of the 3D image will be cut off; the vertical field of
  view is effectively reduced, the wider the aspect ratio compared to 4:3, the
  more will be cut off. In my opinion, it's not a problem at common wide aspect
  ratios like 16:9, and from a quick check at 21:9, it was playable even at that
  aspect ratio.

Extra Configuration
-------------------
As explained above, since Need for Speed High Stakes doesn't support widescreen
resolutions, this patch assumes that the game will at some point be stretched to
fill your desktop resolution. You can override this assumption using the
`targetAspectRatioWidth` and `targetAspectRatioHeight` settings in
`nfshs-widescreen.ini` to explicitly specify the aspect ratio that the game will
be displayed at.

`nfshs-widescreen.ini` also has settings to change what 3D rendering backend is
loaded depending on what renderer has been configured with 3D Setup. In general,
you shouldn't touch these settings unless you know what you're doing; the
correct way to change the 3D renderer is through 3D Setup.

Changelog
---------
* 1.0 (2014-12-10)
  - initial release

Building from Source
--------------------
The source can be found at https://bitbucket.org/fk/porsche-graphics-hacks.
Visual Studio 2013 Express (or up) is required. See the repository readme for
further information.

Legal
-----
This library is Copyright (c) 2014 Felix Krull.

Permission is hereby granted, free of charge, to any person obtaining a
copy of this software and associated documentation files (the "Software"),
to deal in the Software without restriction, including without limitation
the rights to use, copy, modify, merge, publish, distribute, sublicense,
and/or sell copies of the Software, and to permit persons to whom the
Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
DEALINGS IN THE SOFTWARE.

*Microsoft Visual C++ 2013 x86 Redistributable* is a Microsoft product and is
included according to the "Distributable Code" terms of the Microsoft Software
License Terms for Visual Studio 2013.
