SilentPatch for SilentPatch for NFS2: Special Edition, NFS3: Hot Pursuit NFS4: High Stakes and NFS: Porsche Unleashed
Build 1
Last update - 24.09.2023


DESCRIPTION

	This modification addresses several numerous more or less several bugs in the classic Need for Speed games
	from the late 90s - starting from Need for Speed 2: Special Edition, through Need for Speed: Porsche Unleashed.
	Since all those games already have their established unofficial patches, I concentrated my efforts on issues
	either omitted by those patches, or (in the case of NFS2SE and NFS Porsche) caused by them.

	Modern Patches from VEG (NFS3/NFS4) and Verok (NFS2SE/NFS Porsche) are strongly recommended,
	although not mandatory. SilentPatch can work with or without them.

	Featured fixes:

	ESSENTIAL FIXES

	* Locked all (NFS3/NFS Porsche) or specific problematic threads (NFS2SE/NFS4) to one core, while allowing worker
	  threads to use any CPU cores - combining good stability and performance. This option has to be enabled by adding
	  SingleProcAffinity=1 to an INI file named like the game's executable. This change is fully compatible with
	  Modern Patches and overrides its single-core affinity solution.
	* (NFS2SE) Fixed a potential race condition on starting the movie decoding thread.
	* (NFS2SE) Fixed a bug preventing controller button mappings from working correctly with gamepads that report more
	  than 15 buttons (such as the Xbox One controller).
	* (NFS2SE) Fixed the game closing when the controller disconnects during the race.
	* (NFS2SE, Verok's Modern Patch only) Fixed an issue where online races were displayed only on the top half of
	  the screen as if they were split-screen races.
	* (NFS Porsche) Fixed a startup crash due to DirectInput controller enumeration being broken under specific
	  circumstances on Windows 10 and newer.
	* (NFS Porsche) Fixed severe performance issues on Windows 10 and newer when rebinding controls.
	* (NFS Porsche, Verok's Modern Patch only) Fixed unresponsive keyboard inputs after Alt+Tab during the race.
	* (NFS Porsche, Verok's Modern Patch only) Fixed a severe memory leak in OpenGL1 and OpenGL3 thrash drivers
	  occurring after every race.

	MISCELLANEOUS FIXES

	* Alt+F4 now works.
	* Num Lock, Caps Lock, and Scroll Lock don't get forcibly disabled on game launch anymore.
	* (NFS2SE/NFS3/NFS4) Fixed issues with stuttery/unresponsive mouse cursor in menus when using mice with high
	  polling rates.
	* (NFS2SE/NFS3/NFS4) Fixed a controller polling bug resulting in potential incompatibilities with DirectInput
	  wrappers such as Xidi.

	ENHANCEMENTS

	* Pasting text into text boxes now works with Ctrl+V.


INSTALLATION

	You only need to extract the archive contents to your Need for Speed directory.
	Overwrite files when prompted.

	Instructions on locating your game directory can be found here:
	https://cookieplmonster.github.io/setup-instructions/


PATREON & GITHUB SPONSORS SUPPORTERS

	BuckoA51
	Calinou
	deSSy2724
	ddm
	Iman Shahani
	kiwidog
	Lagahan
	mrtaufner
	retrozone.co
	Vetle Ledaal


CONTACT

	zdanio95@gmail.com - e-mail
	cookieplmonster - Discord

Subscribe to my YouTube channel for more footage from my mods!
https://www.youtube.com/@CookiePLMonster

Follow my Twitter account to be up to all my mods updates!
http://twitter.com/__silent_

Also take a look at my blog, featuring modding and programming related articles and more!
https://cookieplmonster.github.io/
