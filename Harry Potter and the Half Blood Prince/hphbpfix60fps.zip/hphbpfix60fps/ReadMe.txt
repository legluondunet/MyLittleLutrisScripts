Harry Potter and the Half Blood Prince

IMPORTANT - You will need to aquire the NO CD exe from the following website for the game you are using this fix for: https://archive.org/details/harry-potter-pc-games-no-cd-cracks

go to show all -> the game you are installing the fix for -> get the no cd for it and copy it into the game directory -> then proceed with this fixes contents.

Make sure you launch the game one time before you use this fix, go to new game or continue game, go to video and make sure your resolution is 640 x 480 for the d3d9.dll to work 

we had to make fps.dll for the fix to work correctly. same as always just dump d3d9.dll d3d9.ini and fps.dll in your game install location next to the game exe and your good to go.

you can edit settings in d3d9.ini 

Default for resolution is (1920 x 1080)

Default for FPS uncap is 60. (YOU WILL NEED VSYNC ON to fix a mouse issue.)

For aspect ratio in this game you need to set two settings if you go above 16:10 which is explained in the ini 

Default aspect ratio is 0 which is (16:9)   

Default for FOV is 0 you can set the fov value 0 is off 1, 2 or 3 each one zooms out a bit more each time.

brought to you by Fix Enhancers  

Team: 

Chip, JokerAlex21, Blankname.

credit to 13AG for d3d9hook base code.

Testers: 

MrDoomStar