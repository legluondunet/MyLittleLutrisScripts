| NFS: Porsche Unleashed Combined Patch v1.1 |
----------------------------------------------


-----------------
| Installation: |
-----------------

1. Copy everything in the "Copy" folder into your game folder, replacing anything it asks you to.

2. Run config.exe as administrator. (If you don't see it, your antivirus probably deleted it since several report a false positive on this file.)

3. Select OpenGL 3 as the renderer and click the screwdriver/wrench icon, then set the following options:
	Exclusive mode: Checked
	Screen resolution: By desktop
	Aspect ratio: Preserve original
	Color depth: 32 bpp
	Refresh rate: 60 Hz (or your monitor's refresh rate)
	Vert. synchronization: On
	Gamma correction: 1.0 (Lower this if you prefer a darker game)
	Depth buffer: 32 bpp

4. Click the "More options" button and set the following options:
	Windowed mode: Your choice
	Fog: Checked
	Filtering: Checked
	Single proc affinity: Unchecked
	CPU Frequency (MHz): 0
	No error reporting: Unchecked
	No movies: Your choice
	Car control: Your choice
	
5. Click Save and close config.exe

6. Add anistropic filtering and anti-aliasing for Porsche.exe through your graphic driver settings.

7. Choose your driver name and photo: (Optional)
	- Rename the file "8Driver.sav" in the SaveData folder to what you'd like your name to be. The number at the front (1-8) selects which photo/driver head to use.
	- Open the player.lst file in the SaveData folder with a text editor, and set the name to whatever you named the .sav file.
	- (Optional - Only affects your name in multiplayer) Open 8Driver.sav in a text editor and do a search for "Driver". Replace the first two instances with whatever the file is called (without the number at the beginning). Don't replace the "FactoryDriver.Car" line.
	
8. Set nfs5.exe to run as administrator (This prevents the game being unable to find/create files when installed in the Program Files (x86) folder

9. Run the game using nfs5.exe (not Porsche.exe). Make sure to set your graphics settings in Options

10. All done! You're ready to play!


------------------
| Documentation: |
------------------

In the "Docs" folder, you will find the readmes and changelogs of the various patches included in the Combined Patch:

	- Enhanced Patch: This was the original unofficial patch for Porsche Unleashed. Only the bug fixes are included in the Combined Patch.
	- NFS5 Essentials Readme: The readme that shipped with the NFS5 Essentials patch.
	- Game Fixes and Extras: List of changes from the NFS5 Essentials patch.
	- Verok's NFSV Patch: The readme for Verok's NFSV Patch which makes up the core of this patch
	- Smooth Shines and Lights: The readme from the Smooth Shines and Lights mod that is included in the Combined Patch.
	- Combined Patch Changes: List of changes made by this patch in addition to the ones previously mentioned