**************************************************
*NFS5 Essentials (formerly Game Fixes and Extras)*
**************************************************
Made by ND4SPD Racer

Feature set:
1. All the 4 Official addon cars - Porsche 911 GT2, GT3, 928 GTS and 959.
2. Patch files to update game to V3.5.20040310 Enhanced - last official patch, patch notes can be found in the readme folder in the enhanced folder.
3. Porsche.exe executable with fix for >2.1 GHz processors - to allow proper loading of textures on modern processors.
4. Additional fixes/features - a full list can be found in Game Fixes and Extras.txt
5. A clean savegame with all the fixes applied (you can use tools such as NFS5 File editor to change the name and photo).

Compatibility step to take for running NFS5 on Windows Vista/7/8:
Run the game in Windows XP (Service Pack 3) compatibility mode.

Installation:
Unzip the files insude the NFS5 installation directory folder into your NFS5 installation directory.

Information:
You can release this mod anywhere as long as you credit me (ND4SPD Racer) as the original author of this mod.