# Issues
Don’t forget to mention game version, which release or branch it came from.\
Source port issues are handled in their respective repositories.

# Pull request
No source ports in main repository.\
I have no way to test and maintain most of them.\
The best I can do is to add a link.

There is no guaranty that any particular PR will be accepted.\
If you are unsure, ask first, make PR second.
