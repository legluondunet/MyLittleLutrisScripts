Controller profiles to  play with Tomb Raider 1 glATI.

x360 controller profile to use with antimicro Tomb Raider --> Tomb Raider 1 glATI.gamecontroller.amgp
You can download Antimicro here: https://github.com/AntiMicro/antimicro

Steam controller profile to use with sc-controller --> Tomb Raider 1 glATI.sccprofile
You can download sc-controller here --> https://github.com/kozec/sc-controller
