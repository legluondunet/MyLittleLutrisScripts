============================================================
Title			: Rune Classic Extended
Author(s)		: Shawn "AmranX" Davison
============================================================

This Readme has been updated on June 17th, 2012.
Release version: 1.1 (June 19th, 2012)

This mod re-implements the ten missing levels which were cut from the Steam release of the game. Rune can certainly be a bit of a grind when played at full length (which I suspect is why these were dropped) but it seemed like it would be nice to have the option for them to be included in the campaign once more.


Installation
============================================================

I'd recommend making a backup of the maps folder before replacing any files in case you want to revert later without re-downloading from Steam. Also take note that loading a save game from a map which has since been replaced may cause issues in some cases.

To install, first remove the suffix '_CUT' from any levels within the ..\Steam\steamapps\common\Rune Classic\Maps directory. There should be ten of them as listed below. (Example, 'DeepUnder4_CUT' should be changed to 'DeepUnder4', and so forth)

DeepUnder1OdinB_CUT -Becomes->   DeepUnder1OdinB
DeepUnder4_CUT      --------->   DeepUnder4
DwarfMap5A_CUT      --------->   DwarfMap5A
DwarfMap3A_CUT      --------->   DwarfMap3A
DwarfMap3B_CUT      --------->   DwarfMap3B
Goblin1_CUT         --------->   Goblin1
Hel3b_CUT           --------->   Hel3b
Hell2End_CUT        --------->   Hell2End
Mountain1_CUT       --------->   Mountain1
ThorMap4B_CUT       --------->   ThorMap4B

Now, copy the 11 map files from the archive into the folder, replacing the originals in the process. You're now ready to play!


Etcetera
============================================================

Here's a list of what was modified in each level. 'Changed transition' refers to changing the next map to be loaded, while 'restored geometry' means I brought over content from Runes original levels so the transitions line up as they do in 1.07 and below. As a long time fan, I made absolutely certain to be faithful both to the original game, and to the gameplay changes made in 1.10.

DeepUnder1Odin <-Changed transition, restored exit geometry.
DeepUnder3 <-Changed transition, restored entry geometry.
Hel1 <-Restored entry geometry.
Hel1b <-Changed transition.
Hel3a <-Changed transition, restored entry geometry.
HelLift <-Changed transition, restored entry geometry.
Goblin1 <-Added 1.10 entry geometry.
Goblin2 <-Restored entry geometry.
ThorMap4A <-Changed transition, restored exit geometry.
THORmap6Loki <-Changed transition, restored exit geometry.
DwarfMap2 <-Changed transition, restored exit geometry.
