#!/bin/bash

cp -R icons ~/.local/share/

gamepath="$PWD"
echo "le répertoire courant est $gamepath"
sed -i -e "s_Path=.*_Path="$gamepath/"_g" -e "s_Exec=.*_Exec="$gamepath"/mj_g" ogs-mahjong.desktop
cp ogs-mahjong.desktop ~/.local/share/applications/
DIR=`dirname $0`
# Create symlink to PCRE library if it's not a Debian based distribution.
if [ ! -e /etc/debian_version ]; then
    LOCAL=$DIR/lib/libpcre.so.3
    # Symlink does not exist.
    if [ ! -e $LOCAL ]; then
        # Search for PCRE library and symlink it if found.
        for dir in /lib64 /lib /usr/lib64 /usr/lib; do
            if [ -e $dir/libpcre.so.0 ]; then
                ln -s $dir/libpcre.so.0 $LOCAL
                break
            elif [ -e $dir/libpcreposix.so.0 ]; then
                ln -s $dir/libpcreposix.so.0 $LOCAL
                break
            fi
        done
    fi
fi
# Launch.
LD_LIBRARY_PATH=$DIR/lib $DIR/lib/mj-bin $DIR/lib $DIR/res 
