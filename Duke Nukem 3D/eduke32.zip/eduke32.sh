#!/bin/bash

LDD_LIBRARY_PATH=libs ./eduke32 -usecwd -cfg config.cfg -j "dn3d-ae"

