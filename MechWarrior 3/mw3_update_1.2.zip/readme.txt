MechWarrior 3
Version 1.2 Update (U.S. and UK)
ReadMe File
MicroProse
17 September 1999


Table of Contents
1)	How to Update to Version 1.2
2)	Version 1.2 Changes
3)	Version 1.1 Changes
4)	Manual Correction
5)	Installation Note
6)	Game Commands
7)	Game Controls
8)	Game Control Configurations
9)	Training Missions
10)	Cockpit
11)	Lancemate Command Screen (F11)
12)	Multiplayer
13)	Gameplay
14)	Controls Screen
15)	Graphics
16)	Video Card Drivers
17)	System Information Utility
18)	U.S. Customer Support
19)	UK Customer Support
20)	License Agreements

How to Update to Version 1.2
Note: This updater works with only the U.S. and UK versions of MechWarrior 3. Do not use this update for 
the German, French or any other language version of the game!

Since this version 1.2 incorporates all the program changes made in version 1.1, you can use this updater to 
update either version 1.0 or version 1.1 of MechWarrior 3.

1.	Download the file MW3V12.EXE to your hard drive. (You will need about 6MB of free space on your 
hard drive.)
2.	Insert the MechWarrior 3 disc into your CD-ROM drive.
3.	Click the Exit button to exit the game.
4.	Open the directory where you downloaded the update.
5.	Double-click the MW3V12.EXE file to start the update.
6.	Click the "Next" button in the dialog box to start the installer for the update.
7.	At the next dialog box when it asks you to insert your MechWarrior 3 CD-ROM, click the "Next" 
button to continue the update.
8.	The updater will automatically update your copy of MechWarrior 3 to version 1.2.
9.	Click the Finish button to complete the update.

If you are having problems updating to version 1.2, we recommend that you uninstall MechWarrior 3 and 
then reinstall the game before running the updater.

After you update to version 1.2, the File Version for MECH3.EXE should now read "1,2."

Version 1.2 Changes
The following problems have been fixed in version 1.2:
?	If 8MB 3-D textures are selected, the program no longer crashes after several waves of Instant Action.
?	The crackling and popping sounds heard on PCI sound cards (such as the Sound Blaster Live! and 
Sound Blaster PCI 128 sound cards) have been eliminated.
?	The Cauldron Born, Puma, Supernova and Vulture configurations now include Double Heat Sinks 
instead of regular Heat Sinks.
?	If the control setup has been customized, installing the update will no longer reset the controls to 
Joystick/Keyboard.

The following multiplayer changes have been made in version 1.2:
?	Your BattleMech's arms will no longer "flail" around on the other players' screens.
?	Your 'Mech will no longer "run in place" on other players' screens.
?	If you quickly type uppercase letters and question marks in the multiplayer chat window, the program 
no longer crashes.
?	Weapon groupings are saved after a player dies and respawns.

The following enhancements have been made in version 1.2:
?	The ability to add maps has been implemented. New maps will be periodically made available for 
download from our Web site.
?	Multiplayer lag and packet loss have been significantly reduced.
?	Reporting of team scores is now possible on the MSN Gaming Zone.
?	Two new multiplayer maps, Durgan City and The Spaceport, have been added.
?	You can now enter IP addresses using the numeric keypad.

Version 1.1 Changes
The following problems were fixed in version 1.1:
?	Using the jump jets in reverse no longer sets the throttle to reverse.
?	A 'Mech that jump jets no longer bounces as the player applies jump jets just as the 'Mech is landing.
?	The program no longer resets the firing mode (Single/Chain/Group Fire) and the damage display mode 
after you continue from mission to mission.
?	The turret no longer disappears in Op 2, Mission 4 (which made the mission unwinnable).
?	Players can no longer enter the Op 2, Mission 4 area during Op 2, Mission 3. This prevents players 
from destroying objectives necessary to complete Op 2, Mission 4.
?	Players can no longer enter the Op 3, Mission 4 area during Op 3, Mission 3. This prevents players 
from destroying objectives necessary to complete Op 3, Mission.
?	Several locations where players could jump jet through the ceiling or fall through the terrain have been 
fixed.
?	The music and sound effects volumes no longer reset between missions.
?	When the music volume is set to the lowest setting, the program no longer accesses the CD-ROM drive.
?	You can now remap your joystick buttons from the user interface (instead of just within the mission).

The following multiplayer problems were fixed in version 1.1:
?	You can now play Team Play games on the MSN Gaming Zone (up to 8 players).
?	The program no longer crashes or loses keyboard control when one player respawns while another 
player has his or her in-game chat window onscreen (accessed via the numeric keypad * key).
?	When you connect over a modem, all alphanumeric characters (including "*") can be entered in the 
Phone Number field. You can now enter an asterisk to disable call waiting.
?	For multiplayer games only, leg armor has been strengthened so that 'Mech legs can take more damage.
?	You can now chat at the Multiplayer Game Setup screen after you save your 'Mech configuration.

The following enhancements were made in version 1.1:
?	Weapons have been adjusted for better game balance, including increasing the heat for Lasers, reducing 
the damage from Autocannons and LBX Autocannons, reducing the knockdown force of LBX 
Autocannons, and increasing the speed of PPCs.
?	The chance that a 'Mech will fall down after taking damage in its legs has been significantly reduced.

The following game control changes were made in version 1.1:
?	Force feedback joystick support has been enhanced with effects for water damping, jump jets, nearby 
explosions, exploding 'Mechs and 'Mechs falling down.
?	The speed of torso twist movement using the mouse has been increased.
?	Keyboard remapping now works when you exit and then restart the game.

Manual Correction
In the "Lancemate/Ally Orders" section of Chapter 6, the manual says to press Shift-F11 for "Await Order" 
and Ctrl-F11 for "Cancel Await Order." The manual is incorrect as both of these functions are now 
implemented in the "Stop" order (F9 key), making the other key commands unnecessary.

Installation Note
If you are installing MechWarrior 3 on a computer system that does not have DirectX installed or has an 
older version of DirectX, you must press the Reinstall button in the DirectX install dialog box.

Game Commands
The following key commands have been added to the game:
Select Next Weapon in a Group	Ctrl-]
Select Previous Weapon in a Group	Ctrl-[
Previous Op Point	Shift-N
Nearest Op Point	Ctrl-N

Because of graphical problems associated with some video cards, the Take Screen Shot command (Ctrl-P) 
has been removed from the game.

Game Controls
When you first start MechWarrior 3, the game will detect whether you have a joystick installed on your 
computer. If you do, the game will use the default joystick controls. If not, MechWarrior 3 will use the 
default mouse controls. 

If you have a joystick but want to use the mouse, click on the Options button at the Main Menu or from the 
Pause menu in the simulation. Then click the Controls button and click the Mouse/Keybd Default button.

MechWarrior 3 supports the use of both the mouse and joystick at the same time. To do this, set up the 
mouse and joystick the way you want them at the Controls screen. Then save your new configuration by 
clicking the Save button.

MechWarrior 3 always loads the latest configuration that you used or the default if no configuration file has 
been created.

MechWarrior 3 supports force feedback joysticks, such as the Microsoft SideWinder Force Feedback Pro. 
Make sure you calibrate your joystick in Windows through the Game Controllers control panel before 
starting the game.

If you are experiencing a problem with the throttle being on constantly (even though you do not have a 
throttle control on your joystick):
1.	Start a mission in MechWarrior 3.
2.	Press the Esc key to access the in-game menu.
3.	Choose Options.
4.	Choose Controls.
5.	Click on Forward Throttle.
6.	Right-click on "Joystick Z axis" to clear this field.
7.	Click the Accept button.
8.	In the dialog box, click the OK button to save your changes.

If you are experiencing a problem with the torso twisting (even though you do not have a rudder control on 
your joystick):
1.	Start a mission in MechWarrior 3.
2.	Press the Esc key to access the in-game menu.
3.	Choose Options.
4.	Choose Controls.
5.	Click on Twist Left.
6.	Right-click on "Joystick Rz axis" to clear this field.
7.	Click the Accept button.
8.	In the dialog box, click the OK button to save your changes.

Game Control Configurations
Keyboard
You cannot map the following keys to any game command:
?	Left Shift
?	Right Shift
?	Left Ctrl
?	Right Ctrl
?	Left Alt
?	Right Alt
?	Break
?	Esc

Although Alt-F4 is not displayed onscreen, you can remap this key combination -- but it is a special case. 
Alt-F4 is set to "Quick Exit" by default. If you remap Alt-F4 to another game function, the only way to 
return Alt-F4 to "Quick Exit" is to reset all the controls to the default.

Joystick
If your joystick is correctly set up under Windows, all the buttons and axes are remappable except for the 
POV (Point of View) hat. If your joystick has more than one POV hat, only the "first" one works and its 
functionality is hard-coded. Version 1.0 of MechWarrior 3 (U.S., U.K., French and German) had a program 
bug that prevented the joystick buttons from being remapped before you started the game. This problem has 
been fixed in version 1.2.

Mouse
The three mouse buttons (left, center and right) can be remapped. The middle button of some mice do not 
work. This problem may be caused by an incorrect installation of the mouse under Windows or because the 
middle button is configured for a special macro operation by the mouse driver.

Analog Axes
The only functions that can be mapped to analog axes are listed below. (These functions can also be 
assigned to individual buttons and/or keys.) No other game functions can be assigned to analog axes.
?	Forward Throttle/Reverse Throttle
?	Turn Left/Turn Right
?	Twist Left/Twist Right
?	Pitch Up/Pitch Down

Training Missions
The game has changed since the voice-over dialogue for the Training missions was recorded.

?	Advanced Combat training mission (#3): Your instructor states that a targeting computer allows the 
player to target a particular body part and that your shots will hit the intended body part while firing 
away from that targeted area. This information is incorrect. The targeting computer only gives you a 
green circle to indicate where to shoot at in order to hit the selected body part. The targeting computer 
calculates where to aim your weapon to hit the selected body part relevant to its velocity and your 
velocity.

?	Advanced Combat training mission (#3): Your instructor states that the jump jets only allow your 
'Mech to jump forward. This information is incorrect. If you did not select "Relaxed Jump Jets" at the 
Options menu, you can still jump forward, backward and straight up. If you did select "Relaxed Jump 
Jets," you can also rotate and move your 'Mech laterally using the jump jets.

Cockpit
If your HUD display is in Map mode (Shift-R), the circle represents the range of your radar, the two yellow 
lines your current field of view, and the red line your current direction of travel. Normally, the red line is in 
the middle of the two yellow lines. If your BattleMech's torso is twisted, the yellow lines indicate which 
way your 'Mech is looking while the red line shows which way your 'Mech is moving.

The BattleMech diagram in the 2-D and HTAL damage displays in the lower left-hand corner faces the 
same way you are facing. The 3-D damage display, however, faces in whatever direction is shown. This 
means that if you damage the left leg of an enemy 'Mech, it will be shown on the left leg of the 2-D damage 
display. In the 3-D damage display, however, if the enemy 'Mech is facing you, the damage is shown on the 
right-hand side of the 'Mech diagram.

Lancemate Command Screen (F11)
You can send lancemates to any area on the map via the Lancemate Command screen (F11). 

To send your lancemates to an area that is within your field of view:
1.	Use the mouse to click on the terrain anywhere that you can see from the Lancemate Command screen.
2.	Select the lancemates that you want to send.
3.	Select either Attack My Target (F6) or Defend My Target (F7).
4.	The selected lancemates will move to the designated position. If you chose Attack My Target, the 
lancemate will attack the nearest enemy unit once the position is reached and continue to attack. If you 
chose Defend My Target, the lancemate will stay in the area, attacking enemy units that come within 
weapon proximity.

You can also send lancemates anywhere within the mission area. The procedure is similar to the steps 
above, except that you can click on the map display instead of within the viewable terrain.

Note that only one order is active at any one time. You cannot split Attack My Target and Defend My 
Target commands between two or more different lancemates within the Lancemate Command screen.

The Lancemate commands of Lock Awaiting Orders (Ctrl-F11) and Cancel Awaiting Orders (Shift-F11) are 
now implemented via the Lancemate: Stop (F9) function.

Multiplayer
In order to play a multiplayer MechWarrior 3 game, you must have Winsock 2 installed first. You can get 
Winsock 2 for Windows 95 by downloading the W95WS2SETUP.EXE file from:
	http://www.microsoft.com/windows95/downloads/contents/wuadmintools/s_wunetworkingtools/

If you are playing a multiplayer MechWarrior 3 game over the Internet or MSN Gaming Zone, we 
recommend the following:
28.8 kps modems	2 to 4 players
33.6 kps modems	2 to 6 players
56 kps modems	2 to 8 players 

For best performance over the Internet, we recommend that you use TCP/IP setting when choosing 
Connection Type. IPX is best used for LAN network games. (MSN Gaming Zone does not require you set 
this parameter.)

All players in a multiplayer game must be running the same version of MechWarrior 3.

If you cannot access the 'Mech Lab or click the I Am Ready button in a multiplayer game, this probably 
means that the host of your multiplayer game selected "Team Play" at the Multiplayer Access screen. You 
must first join a team before you can access the 'Mech Lab or click the "I Am Ready" button.

If you cannot customize your BattleMech in the 'Mech Lab for a multiplayer game, this probably means that 
the host of your multiplayer game selected "Use Stock 'Mechs" at the Multiplayer Game Setup screen. 
Therefore no 'Mech Lab modifications are allowed.

According to page 59 of the manual, anyone can set up teams in a Team Play game. This is incorrect. Only 
the host of the multiplayer game can create teams.

You cannot access the Options screens during a multiplayer game. This means that you cannot access 
options for gameplay, graphics, audio or game controls.

If you go outside the mission boundaries in a multiplayer game, your 'Mech will blow up. The yellow line 
on your radar indicates when you are close to leaving the mission area. You will also hear a warning 
message of "Leaving mission area." If you cross the mission boundary (the red line on the radar), you will 
hear "Mission failed" and your 'Mech will blow up.

To play MechWarrior 3 through a network firewall or proxy server, your network administrator must 
configure the proxy server or firewall to allow DirectX games to pass information through the proxy server 
or firewall. Ask your network administrator to configure the firewall to use the following settings:
?	Allow an initial outbound TCP connection on port 47624
?	Allow subsequent inbound and outbound connections on TCP and UDP ports 2300-2400
?	Set appropriate permissions for DirectPlay (client)

In addition, to play MechWarrior 3 on the MSN Gaming Zone, the following TCP ports on the firewall 
must be open: 28800-28912.

The scores in a multiplayer game read "Kills/Deaths" where Kills is the number of times you destroy 
another 'Mech and Deaths is the number of times you destroy your own 'Mech (not the number of times 
someone else kills you). You can destroy your own 'Mech by overheating it, colliding with another object, 
etc.

If you want to play a multiplayer game over the MSN Gaming Zone, click the Start button on your 
Windows taskbar and select Programs > MicroProse > MechWarrior 3 > MechWarrior 3 on MSN Gaming 
Zone. This will launch your Web browser and take you to the MSN Gaming Zone.

Gameplay
If you are controlling your 'Mech with a mouse, we recommend that Torso Auto Return be turned Off in the 
Gameplay options screen. Otherwise, your BattleMech's torso will return to center whenever you try to turn 
it.

If your lancemates' 'Mechs are destroyed, at the beginning of the next mission, the lancemates will 
automatically be allocated 'Mechs and weapons from your MFB salvage.

If you click the Exit button on the Briefing screen, the game will pause for several moments before 
returning to the Main Menu. 

If you return to a saved game or restart a mission and then click the Launch icon, a dialog box appears that 
says, "You have not allocated salvage from the last mission. Continue? Y/N." Just press "Y" to continue. 
You will see this dialog box if you already took everything you wanted from the salvage the last time you 
were at the Briefing screen, but left some salvage behind that you don't want.

When you Alt-Tab from the game to get to the Windows desktop, the music will still play. 

Controls Screen
For a description of Toggle Torso Mode (numeric keypad Ctrl-0), see "Targeting Controls" on page 24 in 
the manual.

For a description of Freelook ("L" key), see "Targeting Controls" on page 24 in the manual.

For a description of Toggle Enemy Damage Display (Ctrl-D), see "Damage Display" on pages 28�29 in the 
manual.

Graphics
If you change your option for Video Device at the Graphics and Audio screen, and you answer OK to the 
question, MechWarrior 3 will quit and you must restart the game for the change to take effect. 

Matrox Millennium
If you have a Matrox Millennium 2 video card and are having problems starting the game:
1.	Start MechWarrior 3.
2.	At the Main Menu, click the Options button.
3.	Click the Graphics button.
4.	Select "Software Render" for the Video Device option.
5.	Click the Accept button.
6.	Click the Accept button.

Monster 3D (Voodoo 1)
If you have a Monster 3D graphics accelerator with 4MB RAM and switch the Video Device option to 
"Software Render" and then back to "3Dfx DirectX Driver," the game will still use the software renderer for 
graphics. Since this video option is slower than the 3Dfx-specific option, we recommend that you reinstall 
MechWarrior 3.

If you are using an older 3Dfx graphics accelerator (such as a Voodoo 1), we recommend that you 
download the 3Dfx reference drivers listed below.

STB Velocity 128 3D AGP
This video card has a few graphics problems that are not fixed by the latest drivers as of this date:
?	Corrupt in-game textures 
?	'Mech shadow corrupting the textures

Check with your video card manufacturer to see if they have updated this card's drivers.

Resolution
Some video cards may allow you to choose the 1024 x 768 graphics resolution even though the card itself 
doesn't support this resolution due to memory limitations. MechWarrior 3 will not run when the game 
switches to the real-time simulation (instead of the user interface). If you encounter this problem, be sure to 
choose 640 x 480 or 800 x 600 for "Resolution" at the Graphics and Audio options screen.

Video Card Issues
Because MechWarrior 3 uses very advanced graphics programming that takes full advantage of the 
capabilities of 3-D acceleration hardware, you may need to upgrade the drivers for your video card(s) in 
order to take advantage of all the features and solve any graphics problems. 

You may run into one of these problems below. These graphics problems can usually be fixed by upgrading 
to the latest version of the video driver. Please see the list of video drivers below.

Launching MechWarrior 3 causes an invalid page fault
?	Diamond Stealth 3D 2000
?	Diamond Stealth 3D 3000 (Turbo)

Graphics textures are all white and bleached out
?	ATI Rage Pro

Flashing in-game textures
?	Graphics Blaster Exxtreme

Your 'Mech has multiple shadows
?	Diamond Stealth II S220 *
?	Hercules Power Drive
?	Hercules Thriller 3D Series *

Slight flashing on polygonal seams
?	Matrox Millennium G200 AGP *

All textures within the immediate radius of your 'Mech are white and corrupted
?	Grafixstar - Apocalypse

Black boxes appear in the sky textures when playing a MechWarrior 3 mission
?	Matrox M3D *
?	NEC PCX2 chipset *

White hash marks are drawn all over the in-game ground textures (this problem is fixed if you use the latest 
3Dfx reference drivers for the Voodoo 1 card)
?	Righteous Orchid 3D
?	Diamond Monster 3D
?	All cards based on the 3Dfx Voodoo 1 chipset

Pauses about every 20 seconds and all textures streak, especially HUD graphics and the mouse cursor
?	Graphics Blaster RIVA TNT

When you return to MechWarrior 3 from Alt-Tab, all in-game texture are black-and-white
?	Diamond Monster 3D

When you return to MechWarrior 3 from Alt-Tab, game textures are corrupted
?	Diamond Stealth II G460 *
?	Graphics Blaster 3D

The Zoomed In Reticle is not drawn properly
?	ASUS 3DexPlorer 3000

Computer locks after a few seconds of play 
?	Graphics Blaster 3D

The game crashes to the desktop after finishing a Campaign or Instant Action mission
?	Revolution IV(HawkEye, DirectX)

Bluish tint on edges
?	Matrox Mystique *

If the video card listed above has an asterisk next to it, this means that the latest driver that we tested did not 
fix the graphics problem. Please contact the video card's manufacturer to see if they have updated their 
drivers.

Video Card Drivers
You can download these drivers from the Internet. If you are experiencing problems with MechWarrior 3, 
look for your video card below to find the Web address where you can download the appropriate drivers.

Creative Graphics Blaster 3D
Creative Graphics Blaster Exxtreme
Creative Graphics Blaster RIVA TNT
	http://support.soundblaster.com/files/download.asp

Intergraph Intense 3D 100
	http://www.intergraph.com/ics/i3d100/

Diamond Stealth 3000
Diamond Stealth 3D 2000
Diamond Stealth II S220 
Diamond Stealth II G460 
Diamond Monster 3D
	http://www.diamondmm.com/products/drivers/driver-index.html

Matrox MGA Millennium series
Matrox MGA Mystique 200
Matrox MGA Mystique series
Matrox Millennium II series
Matrox Productiva G100 AGP
	http://www.matrox.com/mga/drivers/latest_drivers/home.htm

Rendition Verite 1000
	http://www.rendition.com/download.html

Revolution IV(HawkEye, DirectX)
9FX Motion 531
9FX Reality 334
	http://www.nine.com/support/drivers

ATI Rage Pro Turbo AGP 2X
ATI 3D Rage Pro
ATI Rage II
ATI Rage II+
	http://support.atitech.ca/drivers/drivers.html

STB Nitro 3D (S3 Virge-DX/GX 375/385)
	http://www.stb.com/drivers/nitro/nt3d.html

STB Velocity 128 3D PCI
	http://www.stb.com/drivers/velocity/vl128.html

S3 Velocity 3D (S3 Virge-VX PCI)
	http://www.s3.com/swlib/

Orchid Righteous 3D
	http://www.orchid.com/support/driverlist.html

3DLabs Permedia 2 3D
	http://www.3dlabs.com/drivers/index.html

Hercules Thriller 3D
Hercules Power Drive
	http://www.hercules.com/support/drivers/

3Dfx reference drivers (for all Voodoo cards)
http://www.3dfx.com

Grafixstar � Apocalypse (NEC PCX2 chipsets)
	http://www.videologic.com/software/software.htm

ASUS 3DexPlorer 3000
http://www.asus.com/downloads/driversidx.asp

System Information Utility
If you are experiencing any problems with MechWarrior 3, we recommend running the System Information 
utility. To run this utility, insert the MechWarrior 3 CD-ROM and open the Extras folder. Then double-
click the SYSINFO.EXE file to run the System Information utility.

The System Information utility looks at your computer system and then displays information about your 
computer system such as processor, memory, etc.

 

To save this information to a text file, click the Save button. If you need to call Customer Support, please 
have a printout of this text file handy when you call. If you need to e-mail Customer Support, please include 
a copy of this text file. If you write to Customer Support, please include a printout of this text file with your 
letter.


U.S. Customer Support
If none of the information above helps to solve your problem, please contact Customer Support. 

We recommend running the System Information utility and printing out the information displayed onscreen 
before calling Customer Support with a problem.

*	MicroProse
	2490 Mariner Square Loop
	Alameda, CA 94501
	ATTN: Customer Support

*	(510)864-4550
	9:00 am to 5:00 pm Pacific Time
	Monday through Friday

*	Fax
	(510)864-4602

*	E-mail
	support@microprose.com

Interactive Help Desk: 
For technical help with MicroProse games, check out our Interactive Help Desk at 
http://support.microprose.com. The Interactive Help Desk contains troubleshooting information for our 
games. You can search for help by category or by keyword.

Web Site: 
You can read the latest news and information at our Web site at www.microprose.com. Visit our site for 
technical support, software updates, demos, hints, tips and more.

For more information on playing MechWarrior 3 online, visit our Online Games area at www.games.com.

CompuServe:
To reach our Customer Support board in the Game Publishers B Forum, type go gambpub at any "!" 
prompt. Then select "Section 2" for MicroProse. In addition to posting and reading messages, you can 
download files from the "Libraries (Files)" menu. Send electronic mail to Customer Support at 76004,2223. 

How to Get Help:
If you are having problems with MechWarrior 3, we can best help you if (1) you are at your computer when 
you call and (2) you have the following information handy:
*	Version number of MechWarrior 3
*	Your computer's processor and its speed
*	Your computer's brand and model
*	Total RAM installed in your computer
*	Version of DirectX drivers
*	CD-ROM brand and model name
*	Video card brand and model name
*	Sound card brand and model name
*	Mouse brand and version number of mouse driver
*	Joystick brand and model name
*	Any error message you see in the game


UK Customer Support
If you have problems and require assistance, you can telephone our Technical Support Hotline:
	01454 893900	Monday to Friday 0900 to 1730 GMT/BST

Note: Phoning this number costs the same as a standard rate call no matter where you call from in the UK. 
If you do telephone the Technical Support line, if possible please be sitting in front of your computer and 
have a pen and paper at the ready. Before contacting our Technical Support line, please try to have the 
following information ready so that we may help you more efficiently:

*	The name of the game
*	The make and model of your computer
*	Processor and speed
*	Peripherals
*	Graphics card
*	Version of Windows
*	Amount of memory installed
*	The exact error message reported (if any)
*	The version numbers of DirectX drivers

Please be aware that at certain times of the day our support line may be very busy and the queue may be a 
few minutes long. At these times you will be given the option to leave a message, and one of our operators 
will return
your call at a time that is convenient to you, during normal support operating hours.

E-mail
Alternatively you can e-mail our Technical Support operators.

	E-mail address: microprose_europe@compuserve.com or
uksupport@microprose.ltd.uk

To ensure a prompt reply please summarise your issues as concisely as you can, giving details, as above, of 
the game, the problem or error, any circumstances that you feel relevant and your particular computer 
system. We will endeavour to return your mail within the day.

All letters should be addressed to:

MicroProse Customer Support
The Ridge, Chipping Sodbury,
S. Gloucestershire,
BS37 6BN, UK


-----------------------------------------------------------------------------------------------------------
LICENSE AGREEMENT (U.S.)

***  IMPORTANT  ***

This is a legal agreement between the end user ("You") and Hasbro Interactive, Inc., its affiliates and subsidiaries 
(collectively "Hasbro Interactive"). This Agreement is part of a package (the "Package") that also includes a CD-ROM 
disc (collectively, the "CD-ROM") and certain written materials (the "Documentation"). 

BY INSTALLING THE CD-ROM, YOU ACKNOWLEDGE THAT YOU HAVE READ ALL OF THE TERMS AND 
CONDITIONS OF THIS AGREEMENT, UNDERSTAND THEM, AND AGREE TO BE BOUND BY THEM. YOU 
UNDERSTAND THAT, IF YOU PURCHASED THE PACKAGE FROM AN AUTHORIZED RESELLER OF 
HASBRO INTERACTIVE, THAT RESELLER IS NOT HASBRO INTERACTIVE'S AGENT AND IS NOT 
AUTHORIZED TO MAKE ANY REPRESENTATIONS, CONDITIONS OR WARRANTIES, STATUTORY OR 
OTHERWISE, ON HASBRO INTERACTIVE'S BEHALF NOR TO VARY ANY OF THE TERMS OR 
CONDITIONS OF THIS AGREEMENT. 

If You do not agree to the terms of this Agreement, promptly return the entire Package to the place You obtained it for 
a full refund.

LIMITED LICENSE: You are entitled to use this CD-ROM for your own use, but may not sell or transfer 
reproductions of the CD-ROM or Documentation to other parties in any way. You may use one copy of the CD-ROM 
on a single terminal connected to a single computer. You may not network the CD-ROM or otherwise use it on more 
than one computer or computer terminal at the same time. 

You acknowledge that Hasbro Interactive is not responsible for the Internet or whether it should continue to exist in its 
present form or whether or not a government or governmental agency, either foreign or domestic, will control, regulate 
or disband the Internet.

OWNERSHIP; COPYRIGHT: Title to the CD-ROM and the Documentation, and patents, copyrights and all other 
property rights applicable thereto, shall at all times remain solely and exclusively with Hasbro Interactive and its 
licensors, and You shall not take any action inconsistent with such title. The CD-ROM and the Documentation are 
protected by United States, Canadian and other applicable laws and by international treaty provisions. Any rights not 
expressly granted herein are reserved to Hasbro Interactive and its licensors. 

OTHER RESTRICTIONS: You may not cause or permit the disclosure, copying, renting, licensing, sublicensing, 
leasing, disseminating or otherwise distributing of the CD-ROM or the Documentation by any means or in any form, 
without the prior written consent of Hasbro Interactive. You may not modify, enhance, supplement, create derivative 
work from, adapt, translate, reverse engineer, decompile, disassemble or otherwise reduce the CD-ROM to human 
readable form. 

LIMITED WARRANTY:

Hasbro Interactive warrants for a period of ninety (90) days following original retail purchase of this copy of the game 
that the CD-ROM is free from substantial errors or defects that will materially interfere with the operation of the CD-
ROM as described in the Documentation. This limited warranty applies to the initial purchaser only. EXCEPT AS 
STATED ABOVE, HASBRO INTERACTIVE MAKES NO OTHER WARRANTY OR CONDITION, EXPRESS OR 
IMPLIED, STATUTORY OR OTHERWISE, REGARDING THIS CD-ROM. THE IMPLIED WARRANTY THAT 
THE CD-ROM IS FIT FOR A PARTICULAR PURPOSE AND THE IMPLIED WARRANTY OF 
MERCHANTABILITY SHALL BOTH BE LIMITED TO THE NINETY (90) DAY DURATION OF THIS LIMITED 
EXPRESS WARRANTY. THESE AND ANY OTHER IMPLIED WARRANTIES OR CONDITIONS, STATUTORY 
OR OTHERWISE, ARE OTHERWISE EXPRESSLY AND SPECIFICALLY DISCLAIMED. Some jurisdictions do 
not allow limitations on how long an implied warranty or condition lasts, so the above limitation may not apply to You. 
This limited warranty gives You specific legal rights, and you may also have other rights which vary from jurisdiction 
to jurisdiction. 

If you believe you have found any such error or defect in the CD-ROM during the warranty period, (i) if you are in the 
United States, call Hasbro Interactive's Consumer Affairs Department at 800-683-5847 between the hours of 8:00 a.m. 
and 12:00 a.m midnight. Monday through Friday (Eastern Time) and 8:00 a.m. to 8:00 p.m. Saturday and Sunday, 
holidays excluded, and provide your Product number; or (ii) if you are outside the United States, send your original 
CD-ROM disc to Hasbro Interactive at Caswell Way, Newport, Gwent, NP9 0YH, United Kingdom, together with a 
dated proof of purchase, your Product number, a brief description of such error or defect and the address to which it is 
to be returned. If you have a problem resulting from a manufacturing defect in the CD-ROM, Hasbro Interactive's 
entire liability and Your exclusive remedy for breach of this limited warranty shall be the replacement of the CD-ROM, 
within a reasonable period of time and without charge, with a corrected version of the CD-ROM. Some jurisdictions do 
not allow the exclusion or limitation of relief, incidental or consequential damages, so the above limitation or exclusion 
may not apply to You.

HASBRO INTERACTIVE SHALL NOT BE LIABLE FOR SPECIAL, INCIDENTAL, CONSEQUENTIAL, 
EXEMPLARY OR OTHER INDIRECT DAMAGES, EVEN IF HASBRO INTERACTIVE IS ADVISED OF OR 
AWARE OF THE POSSIBILITY OF SUCH DAMAGES. IN NO EVENT SHALL HASBRO INTERACTIVE'S 
LIABILITY EXCEED THE PURCHASE PRICE OF THIS PACKAGE. Some jurisdictions do not allow the exclusion 
or limitation of special, incidental, consequential, indirect or exemplary damages, or the limitation of liability to 
specified amounts, so the above limitation or exclusion may not apply to You.

GENERAL: This Agreement constitutes the entire understanding between Hasbro Interactive and You with respect to 
subject matter hereof. Any change to this Agreement must be in writing, signed by Hasbro Interactive and You. Terms 
and conditions as set forth in any purchase order which differ from, conflict with, or are not included in this 
Agreement, shall not become part of this Agreement unless specifically accepted by Hasbro Interactive in writing. You 
shall be responsible for and shall pay, and shall reimburse Hasbro Interactive on request if Hasbro Interactive is 
required to pay, any sales, use, value added (VAT), consumption or other tax (excluding any tax that is based on 
Hasbro Interactive's net income), assessment, duty, tariff, or other fee or charge of any kind or nature that is levied or 
imposed by any governmental authority on the Package. 

EXPORT AND IMPORT COMPLIANCE: In the event You export the CD-ROM or the Documentation from the 
country in which You first received it, You assume the responsibility for compliance with all applicable export and re-
export regulations, as the case may be. 

GOVERNING LAW; ARBITRATION: This Agreement shall be governed by, and any arbitration hereunder shall 
apply, the laws of the Commonwealth of Massachusetts, U.S.A., excluding (a) its conflicts of laws principles; (b) the 
United Nations Convention on Contracts for the International Sale of Goods; (c) the 1974 Convention on the 
Limitation Period in the International Sale of Goods; and (d) the Protocol amending the 1974 Convention, done at 
Vienna April 11, 1980. 

Any dispute, controversy or claim arising out of or relating to this Agreement or to a breach hereof, including its 
interpretation, performance or termination, shall be finally resolved by arbitration. The arbitration shall be conducted 
by three (3) arbitrators, one to be appointed by Hasbro Interactive, one to be appointed by You and a third being 
nominated by the two arbitrators so selected or, if they cannot agree on a third arbitrator, by the President of the 
American Arbitration Association ("AAA"). The arbitration shall be conducted in English and in accordance with the 
commercial arbitration rules of the AAA. The arbitration, including the rendering of the award, shall take place in 
Boston, Massachusetts, and shall be the exclusive forum for resolving such dispute, controversy or claim. The decision 
of the arbitrators shall be binding upon the parties hereto, and the expense of the arbitration (including without 
limitation the award of attorneys' fees to the prevailing party) shall be paid as the arbitrators determine. The decision of 
the arbitrators shall be executory, and judgment thereon may be entered by any court of competent jurisdiction. 
Notwithstanding anything contained in this Paragraph to the contrary, Hasbro Interactive shall have the right to 
institute judicial proceedings against You or anyone acting by, through or under You, in order to enforce Hasbro 
Interactive's rights hereunder through reformation of contract, specific performance, injunction or similar equitable 
relief.



___________________________________________________________
LICENCE AGREEMENT (UK)

***  IMPORTANT  ***

1.	LICENCE
The software and all images, photography, animations, video, audio, music and text contained on the 
enclosed CD-ROM and this manual, (together, 'the Product') are protected by copyright and other 
intellectual property rights
which are owned by or licensed to Hasbro Interactive Limited of 2 Roundwood Avenue, Stockley Park, 
Uxbridge, UB11 1AZ ('Hasbro')

Hasbro grants to you as the original purchaser of this Product a non-transferable right to use the Product for 
your own personal and private use and not in connection with any business activity. Unless otherwise 
permitted by law, no part of this Product may be copied, reproduced, translated, modified, decompiled or 
reduced into any electronic or other form without the prior written consent of Hasbro. You may not rent or 
lease, or sell or transfer copies of the Product or any part of it.

2.	WARRANTY
Hasbro warrants to you only that for a period of ninety days from purchase the Product will perform 
substantially in accordance with the specifications set out in this manual and that the original CD-ROM disk 
itself will be free
from defects in materials and workmanship.

During this period the Product, if defective, will be replaced free of charge if returned to Hasbro at Caswell 
Way, Newport, Gwent, NP9 0YH, together with a dated proof of purchase, a brief description of the defect 
and the address to which it is to be returned. Any replacement will be warranted for a further 90 day period. 
This warranty does not affect your statutory rights in any way.

This warranty does not apply to defects caused by misuse, neglect, incorrect installation, damage, alteration, 
repair or excessive wear.

3.	LIABILITY
Except as stated at 2 above, all conditions, warranties, terms, representations and undertakings express or 
implied, statutory or otherwise, in respect of the Product are expressly excluded.

Hasbro's liability to you shall under no circumstances exceed the original retail price of the Product and 
Hasbro does not accept liability for any indirect or consequential damage or loss (even if it is aware that the 
possibility of such damage or loss) including lost profits or revenues, or for any damages, costs or loss 
incurred as a result of loss of time or data or from any other cause.

Nothing set out above shall limit or exclude the Hasbro's liability to you for death or personal injury 
resulting from its own negligence or any other liability not capable of exclusion or limitation by law.

If you do not agree to be bound by these terms, you should immediately return the Product to Hasbro at 
Caswell Way, Newport, Gwent, NP9 OYH, together with a dated proof of purchase, for a full refund.
