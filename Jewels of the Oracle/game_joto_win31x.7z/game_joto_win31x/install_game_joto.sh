#!/bin/bash

./dos2unix C/WINDOWS/PROGMAN.INI C/WINDOWS/WIN.INI

# C/WINDOWS/PROGMAN.INI
sed -i "s/Window=.*/Window=401 372 913 708 1/" C/WINDOWS/PROGMAN.INI
sed -i '$a\Group7=C:\\WINDOWS\\JEWELSOF.GRP' C/WINDOWS/PROGMAN.INI

# C/WINDOWS/WIN.INI
sed -i "s/Wallpaper=.*/Wallpaper=JOTO.BMP/" C/WINDOWS/WIN.INI

./unix2dos C/WINDOWS/PROGMAN.INI C/WINDOWS/WIN.INI

rm -f -r install_game_joto.sh
