#!/bin/bash

./dos2unix C/WINDOWS/WIN.INI

# C/WINDOWS/WIN.INI
sed -i "s/Wallpaper=.*/Wallpaper=JOTO.BMP/" C/WINDOWS/WIN.INI

./unix2dos C/WINDOWS/WIN.INI

rm -f -r install_game_joto.sh
