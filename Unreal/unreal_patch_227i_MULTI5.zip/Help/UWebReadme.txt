*************************
*Unreal 227e WebServer*
*************************

To install:
-Edit WebServer.ini (key things to configure):
	* ListenPort - The port for accepting connections (default web site port is 80, but make sure its a port that is forwarded on router/firewall settings).
	* Accounts - Accounts users can access the site on (username and password is REQUIRED when accessing the webserver, suggested 1 account/user).
	* bOnlyOnePerUser - Only set this to False when you want to allow multiplie users use same account;s in same time.
-Edit Unreal.ini:
	* ServerActors=UWebAdmin.WebAdminManager (Note that do NOT add this mod on ServerPackages)!
-Boot up your server.
-Open up Mozilla Firefox (or oldskool Internet Explorer) and write on address tab: <your server IP>:<your WebServer port>.
	At this point it should ask you for Username/Password.
	And when thats done, you're in it to do whatsoever with your server.

Features:
-Restart map - Restart currently playing map.
-Switch map - Switch map to selected map/game/mutators (note that maplists configure must be enabled to access maplist).
-Current game - You see list of players (ID/Name/Ping/Score/IP) and controls to Kick/Ban them.
-Server console - See a list of chat messages in server aswell a command line where you can chat with the players to execute a command on server.
-Banlist - See a full list of all banned clients, also lets you unban them.
-Defaults - Server configure page:
	* Main Game config - Lets you configure basic game rules (such as max players/server packages/server actors/redirecting etc).
	* ServerInfo config - Lets you configure public server rules (such as server name/admin name/MOTD).
	* Maplists - lets you configure maplists (for DeathMatch based games, NOT for Coop).
	* Mod Configures - Custom mods configures page (by default it contains configures for DeathMatch, TeamGame, Cooperative).

To add an own custom mod configure page:
-Create a class which extends UWebAdmin.ModPageContent.
-You can look for example how to do this from built-in classes: DMPageConfig, TDMPageConfig, CPPageConfig.
-Create an INT file for the package (MyMod.int):
[public]
Object=(Name=MyMod.MyModPageConfig,Class=Class,MetaClass=UWebAdmin.ModPageContent,Description="Super Mutator")
