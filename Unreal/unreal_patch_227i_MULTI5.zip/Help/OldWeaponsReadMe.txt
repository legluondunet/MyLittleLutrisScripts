OldWeapons v1.3.1 ReadMe
========================

The package should include:

- OldWeapons.u (-> System)
- OldWeaponsSounds.uax (-> Sounds)
- OldWeaponsTex.utx (-> Textures)
- OldWeapons.txt (-> Help)


Mutators:
---------

OldWeapons.OldMutator - Replaces all original Unreal weapons to classic ones

Summons:
--------

OldWeapons.Old* (replace * to original class name, like OldMinigun, OldASMD)

===================================================================================

// Version 1.3.1 - compiled 240609
// Copyright (c) Skw