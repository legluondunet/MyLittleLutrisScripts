#!/bin/bash

LD_LIBRARY_PATH=libs ./devilutionx
