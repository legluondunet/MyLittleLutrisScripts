#!/bin/bash

if [ ! -f ~/.local/share/icons/devilutionX.png ]
then
echo "icônes non trouvées"
cp -R icons ~/.local/share/
fi

gamepath="$PWD"
echo "le répertoire courant est $gamepath"
sed -i -e "s_Path=.*_Path="$gamepath/"_g" -e "s_Exec=.*_Exec="$gamepath"/devilutionx.sh_g" devilutionX.desktop

mkdir -p ~/.local/share/applications/
cp devilutionX.desktop ~/.local/share/applications/
chmod +x  ~/.local/share/applications/devilutionX.desktop

LD_LIBRARY_PATH=libs ./devilutionx

