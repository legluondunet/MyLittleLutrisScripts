~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
HD UI Menu Pack
Pure Vanilla Edition
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
for Knights of the Old Republic

v1.1 - 20180318
by ndix UR (DeadlyStream user)

This modification adds high resolution (2K) UI menu textures. For the most part,
a 4x increase in resolution over the originals. Everything is redrawn as
vector art, no modified scale-ups here.

This package is focused on menu backgrounds, and includes some of the overlay
components for the menus.

Pure Vanilla Edition aims to provide the closest match to the original menu
texture assets.

Textures are encoded in game-native TPC format, using DXT compression.

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
REQUIREMENTS
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
You must be running menus at a high resolution for this to really work. At the 
default menu size, this mod will probably look bad.

You must have KotOR High Resolution Menus
(http://deadlystream.com/forum/files/file/1159-kotor-high-resolution-menus/) or
an equivalent mod installed.

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
INSTALL / UNINSTALL
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
To install, copy the files from the package Override/ folder to the Override/
folder for your KOTOR game installation.

To uninstall, remove the TPC files for this package from your KOTOR game
Override/ folder.

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
LEGAL
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
THIS MODIFICATION IS NOT MADE, DISTRIBUTED, OR SUPPORTED BY OBSIDIAN, OR
LUCASARTS ENTERTAINMENT COMPANY LLC.
ELEMENTS TM LUCASARTS ENTERTAINMENT COMPANY LLC AND/OR ITS LICENSORS.

The content of this mod is free for use and reuse, with no implied warranty,
you can redistribute it, in original or modified form. If you do, a credit
of some kind is nice but not required.
