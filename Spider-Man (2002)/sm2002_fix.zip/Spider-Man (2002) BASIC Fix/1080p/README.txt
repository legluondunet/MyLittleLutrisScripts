Spiderman 2002 Fix

Make sure you got the 1.3 patch for this game before you play it its important you can get it here 

https://community.pcgamingwiki.com/files/file/791-spider-man-the-movie-patch-13/

FMV's are now fixed you can toggle the fix for them in d3d8.ini under
[FMV]
Hook=1 

this will simply turn fullscreen FMV fix on or off 1 is on my custom FMV fulscreen functionality 0 is off the original game FMV playback.

you can edit settings in d3d8.ini 

Default for resolution is 1920 x 1080 resolution you can set this as you desire in d3d8.dll.

Default for FOV is 0 which is off/ original game FOV you can set it out using either = 1,2, 3 or 4 each one will set camera zoomed out further incrementally. 

Default for FPS is 60 you can change it as you wish.

brought to you by Fix Enhancers 

Team: 

Chip, JokerAlex21.

credit to  Elisha Riedlinger and 13AG for d3d9hook base code.