Harry Potter and the Deathly Hallows Part 1

IMPORTANT - You will need to aquire the NO CD exe from the following website for the game you are using this fix for: https://archive.org/details/harry-potter-pc-games-no-cd-cracks

go to show all -> the game you are installing the fix for -> get the no cd for it and copy it into the game directory -> then proceed with this fixes contents.

simply put the d3d9.dll and d3d9.ini into your game folder next to the game exe and your good to go 

FOV is edited so that its not so zoomed in with this fix 

you can edit settings in d3d9.ini 

Default aspect ratio is 0 which is (16:9)   

Default for FPS cap is 60 you can change it as you like or uncap with 0, the game will start with 30fps you can hit "9" on your keyboard (not the numpad) to toggle between 30 original fps and the fps you choose in the ini.
this is because there is issues with uncapping fps tied to the menus so you can toggle around these issues if you wish now using the "9" key toggle. so when you get into the game hit "9" and it will go to the uncapped fps.
if pressing "9" doesnt work the first time you press it then just press it again untill the fps changes for you. then after it will just go between 30 and the fps you set in the ini.

brought to you by Fix Enhancers 

[this fix as it stands is a beta and the game is still being looked into, we are looking into capping the menus to 30fps so they dont run so fast. Future updates will be posted so keep an eye out] 

Team: 

Chip, JokerAlex21, Blankname.

credit to  Elisha Riedlinger and 13AG for d3d9hook base code.
