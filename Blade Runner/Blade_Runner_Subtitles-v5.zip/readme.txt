Blade_Runner_Subtitles
Version: 5
------------

This package adds subtitles to Blade Runner running in ScummVM.
It currently includes French subtitles for the French official version 
and English subtitles for the other supported versions of the game.

INSTRUCTIONS:
-------------

Simply copy the SUBTITLES.MIX file into the directory with the *.mix files
from your copy of the game.

In ScummVM, you can activate the subtitles in game, under the settings section.


CHANGELOG:
----------
v5 (17/12/2019)
* Corrections and improvements for the French transcript.

v4 (16/09/2019)
* Numerous corrections and improvements for the French transcript by Kwama57. 
* Additional English transcript fixes.

v3 (22/07/2019)
* Added a full French transcript by Kwama57 for the French official version. 
* Various English transcript fixes.

v2 (16/06/2019)
* Facilitate support for all the official localized versions of the game
  (French, Italian, German, Spanish) with a single subtitles.mix file.
  Currently, all versions will show the English text, the audio still needs
  to be transcribed for the non-English versions.
* Various spelling corrections and consistency improvements with respect to
  terms used.

v1 (25/12/2018)
* Initial release used during development.
* Only the English version of the game and the Russian version by
  Fargus Multimedia are supported. The Russian version will still show
  English subtitles.


CREDITS:
--------

English subtitles arranged by Thanasis "praetorian" Antoniou
French subtitles arranged by Kwama57
