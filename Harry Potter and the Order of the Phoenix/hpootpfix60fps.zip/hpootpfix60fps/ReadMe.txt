Harry Potter and the Order of the Phoenix fix 

IMPORTANT - You will need to aquire the NO CD exe from the following website for the game you are using this fix for: https://archive.org/details/harry-potter-pc-games-no-cd-cracks

go to show all -> the game you are installing the fix for -> get the no cd for it and copy it into the game directory -> then proceed with this fixes contents.

Make sure you launch the game one time before you use this fix, go to new game or continue game, go to video and make sure your resolution is 640 x 480 for the d3d9.dll to work 

simply put the d3d9.dll and d3d9.ini and fps.dll into your game folder next to the game exe and your good to go 

FPS is 60 in this fix, leave v-sync on in your pc and enjoy!

you can edit settings in d3d9.ini 

Default for FOV is 0 which is off or the games original fov, you can set this to 1, 2 or 3 each one will set the fov to slightly more zoomed out each time in game. 0 is off or games original fov.  

Default for resolution is (1920 x 1080) 

Default for aspect ratio is 0 which is (16:9) 

brought to you by Fix Enhancers 

Team: 

Chip, JokerAlex21, Blankname.

credit to 13AG for d3d9hook base code.

Testers: 

MrDoomStar