#!/bin/bash

./dos2unix C/WINDOWS/PROGMAN.INI C/WINDOWS/SYSTEM.INI C/WINDOWS/WIN.INI 

# C/WINDOWS/PROGMAN.INI
sed -i "s/Order=.*/Order= 2 3 4 1 6 5/" C/WINDOWS/PROGMAN.INI
sed -i '/AUDIOSOF.GRP/a Group6=C:\\WINDOWS\\QUICKTIM.GRP' C/WINDOWS/PROGMAN.INI\

# C/WINDOWS/SYSTEM.INI
sed -i '/CDAudio=mcicda.drv/a QTWVideo=C:\\WINDOWS\\SYSTEM\\MCIQTW.DRV' C/WINDOWS/SYSTEM.INI

# C/WINDOWS/WIN.INI
sed -i '/hlp=winhelp.exe \^.hlp/a mov=C:\\WINDOWS\\PLAYER.EXE \^.mov \
pic=C:\\WINDOWS\\VIEWER.EXE \^.pic \ ' C/WINDOWS/WIN.INI

sed -i '/rmi=sequencer/a mov=QTWVideo \
pic=QTWVideo \
jpg=QTWVideo \
' C/WINDOWS/WIN.INI

sed -i '/PBrush=Image Paintbrush,Image Paintbrush,pbrush.exe,picture/a PlayerFrameClass=QuickTime Movie,QuickTime Movie,c:\\windows\\player.exe,picture \
ViewerFrameClass=QuickTime Picture,QuickTime Picture,c:\\windows\\viewer.exe,picture ' C/WINDOWS/WIN.INI


./unix2dos C/WINDOWS/PROGMAN.INI C/WINDOWS/SYSTEM.INI C/WINDOWS/WIN.INI 

rm -f -r install_app_qt16.sh
