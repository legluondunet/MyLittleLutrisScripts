#!/bin/bash

# C/WINDOWS/PROGMAN.INI
sed -i "s/display.drv=vga.drv/display.drv=S3VSND.DRV/" C/WINDOWS/PROGMAN.INI

# C/WINDOWS/SYSTEM.INI
sed -i "s/386grabber=vga.3gr/386grabber=S3911GRB.3GR/" C/WINDOWS/SYSTEM.INI
sed -i "s/286grabber=vgacolor.2gr/286grabber=VGACOLOR.2GR/" C/WINDOWS/SYSTEM.INI
sed -i "s/display.drv=vga.drv/display.drv=S3VSND.DRV/" C/WINDOWS/SYSTEM.INI
sed -i "s/display.drv=VGA/display.drv=S3 864 1.41B5  640x480 16.7M colors/" C/WINDOWS/SYSTEM.INI
sed -i "s/display=\*vddvga/display=VDDS3VSN.386/" C/WINDOWS/SYSTEM.INI

sed -i -e '$a\
[DISPLAY]\
dac-type=nbt\
polygon-support=on\
ellipse-support=on\
scache=on\
textrmw=0\
fastmmio=on\
screen-size=640\
color-format=32\
dpi=96' C/WINDOWS/SYSTEM.INI

# cp -r modified/* C
cp -r new/* C
rm -f -r modified new install_drivers.sh
