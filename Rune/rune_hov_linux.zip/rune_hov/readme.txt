
				Rune: Halls of Valhalla
				(http://www.runegame.com/hov.php)

===============================================================

INSTALLING THE GAME
==================

	Установить поверх установленной Rune, запускать тем же 
	бинарником

NOTES
======

	За рецепт приготовления спасибо SilentLexx с l.o.r

TECHNICAL SUPPORT
===================

	l.o.r:   http://www.linux.org.ru/view-message.jsp?msgid=2832103
	t.ru:    http://torrents.ru/forum/viewtopic.php?t=196544

6axo
