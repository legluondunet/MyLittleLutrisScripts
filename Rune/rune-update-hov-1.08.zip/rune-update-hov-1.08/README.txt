--- Rune 1.09 Mod Pack Prerelease, Public Beta 08, rev. e ---

This is a work in progress. Email any bug reports to froznanus@fuse.net, but make sure to check the "Known Bugs/Glitches" section first.


#### Known Bugs / Glitches / Issues ########

- 1.09 Gametpes: HeadBall CTT and Coop do not show the pDetails menu. The CoAdmin commands, however, work perfectly fine.
- Using AntiTCC, TRBP3, NixTheUndead or other such mutators will cause the client to crash on join. You don't need these mutators, just configure their counterparts in beta109.ini
- ItemSwap causes replaced items to dissolve on map start in most Arenas (Champions is OK)
- LogDamage displays incorrectly in team sizes over 4v4 (returns to normal when teamsize drops under 5)

#############################################

Installation:

1. Copy everything in System over into your Rune\System folder.
2. Copy over your Rune\Web folder with the one provided here.
 (If you have Coop, HeadBall and/or CapTheTorch, these are the same versions.)
3. It's recommended to backup your Arena.u, RuneServerAdmin.u

note: the new RuneServerAdmin and Web dir is only needed for linux servers using the text fix.

#############################################

Configuration:

- In Rune.ini, add ServerPackages=beta8e under [Engine.GameEngine]
- Configure your server in beta109.ini.

[beta8e.zStorage] - The CoAdmin main controls. All 1.09 gametypes use these.
EnterPassword is the main CoAdmin password used with the command "pLogin" "pdetails" will bring up the command list.

If SATools = True, refer to the section [beta8e.Settings] and [beta8e.PlayerSettings] for its main options.

If SANames = True, refer to the section [beta8e.DisplayNames]

** If you're starting SATools and/or SANames in the command line set them FALSE in beta109.ini **

-Save, then Launch your server in one of the 1.09 Game Modes.

Ideal Startup Command line: mutator=beta8e.TCCLite,beta8e.Settings,beta8e.SANames,beta8e.ItemSwap

#########################################################


Integrated Mutators:

- 1.09 TCCLite: A version of AntiTCC v2.2 which uses far less server CPU. Can run disabled but needed for Custom skins.
- 1.09 ItemSwap: Originally "Sheena's Choice" by MacBeth. Switches Item A for Item B. Required for the fixed boneclub, fancy battlesword, Balanced Runes, Health Wars, and Instant Gib.
- 1.09 SATools: Updated version of SATools3c by MacBeth, works with or without CoAdmin gametypes. Added some commands.
- 1.09 SANames: Gives Player status at a distance, and optional Names over heads. A Standalone Component of SATools.
- 1.09 LogDamage: CoAdmin component for Arena damage stats. Loads on its own so no need to activate this one.


Integrated Mods:

- Arena.u: Blitznuckel's Arena update. Includes optional Auto teamsize changes up to 8v8 on supported maps. Fully configurable. By default, Auto teamsize is off. To enable it, replace the following Rune.ini section with this one.

[Arena.ArenaGameInfo]
bAllowLimbSever=false
TimeBetweenMatch=5
MaxTeamSupport=8
bNoMonsters=False
bHumansOnly=False
bCoopWeaponMode=False
bClassicDeathMessages=False
bAutoArenaTeamSizeEnabled=True
secondsBeforeTeamSizeChange=15

- Or, just append the last 2 lines and set the MaxTeamSupport to 8.

- 1.09 Arena Match: CoAdmin pre-configured and hooked to Blitznuckel's Arena. Gives LogDamage and Auto teamsize and 8v8 support by default. Supports the CoAdmin admin toolkit and saves scores (no reconnect score clears, and restored score after connection failure)

- 1.09 RuneMatch [CoAdmin]: CoAdmin DeathMatch, saves scores, CoAdmin commands and features.

- 1.09 TeamGame [CoAdmin]: CoAdmin TeamGame.

Balanced Runes:

- Hand Axe: Ragnar's ground speed is increased 15% while ghost, allowing him to chop down runners a little easier.
- Roman Sword: Two hits of the flame sword power will kill in deathmatch. Roughly equal to a DWS with no sever chance.
- Bone Club: Now costs 2 runes of lesser power to use. Increased to its Rune 1.0 duration (15.0)
- Viking Broad Sword: Vampire Attack fills rage bar if Ragnar is at full health. (50% health -> rage conversion)
- Dwarven Work Sword: Restored some of its 1.0 devastation. 50% damage increase for lightning Zaps. (4.5, from 3.0. Rune 1.0 zap strength was 10)


####################################################

Changes:

beta 8e:

- Wrote a simple load balancer for the anti-cheat. This should solve the sporadic lag/missing swing bug and speed things up on the client and server side.
- fixed the Linux server text fix enabled RuneServerAdmin to conform to the changes made to LinuxFixBeta
- fixed the broadcast bug which could allow abuse of the AntiTCC alert system.
- fixed a replication bug which could cause the Linux Fix and part of AntiTCC to be turned off.
- Did some code cleanup, and a few other performance related tweaks.

beta 8d:

- fixed weird lag issue when using the new RMenu
- fixed Playernames and chats containing the symbol "" to fail to process in LinuxFix
- fixed Speedhack detection. Now good clients won't be locked for "speedhacking" in error.
- Discovered a laggy area of mod code (Timer), moved the code
also moved the original CoAdmin code using this event. Should give a small performance boost.

beta 8c:
- Engine can now be used Client side. No major updates yet.
- Updated the DragonMightArena mutator:
a) Added a custom death message for fist.
b) Throw kills no longer cause 3 script warnings (Accessed null) each
c) Conforms to the changes to the Linux fix
d) Mutator name is now beta8e.DMA (no change if using pDMA in game or DragonMightArena=True in beta109.ini)
- Fixed the 109 Engine compile to allow Pre-108 clients to join (Bug affected beta8, beta8a, and beta8b)
- Added a new font into the Engine used in the main menu
- Released an updated version of the Rune Menu skin. Unfortunately the bugged engine versions cause problems when using this Menu+Engine
This is *NOT* a problem with this new version, the bug is in the older Engine versions.

beta 8b:
- Fixed players being locked for "Automatic Turning" in error.
- Redid Linux Server Text filter so that names are shown correctly in the server query
- Fixed a bug where players using names including special characters would find their names converted in their menus when changing skins and teams

beta 8a:
- Changed TCCLite interval to choose a random number of ticks between checks to prevent new cheats from predicting the old cycle (20 ticks)

Beta 8:
- Removed the need for duplicate AdminPassword entry in beta109.ini. AdminLogin now functions as usual but also gives full pLogin
- Blocked "admin get" and "admin set" for critical server information (WebAdmin, Passwords, Ports, etc)
- Blocked binding player turns to keys, but also blocked gamepad support (GamePad players should google "xPadder free")
- Began work on the 1.09 Engine.u - Waiting on Zora to make a linux version to support a "Version 109"
- Split the Linux Server Text filter into its own .u file, this has many benefits:
a) Reduced redundant coding, dropping beta8's file size by 200k from beta7
b) RuneServerAdmin no longer needs a new version each beta version
c) The Linux Fix can be updated without compiling a new beta version

Beta 7f:

- Began work on an Anti-Aimbot update for TCCLite.
- Redid the Speedhack detection to defend against the newest and most aggressive speedhack.

Beta 7d:

- Fixed a flaw in the Anti-Speedhack which actually caused unintentional (and malicious) speedhacking.
- This fix closed a hole which allowed the server crash to succeed under certain conditions.

Beta 7b:

- Fixed a bug causing Players using the HOV_GoldValkyrie skin to be unable to join the server.
- Removed old dependencies for 1.08 skins, allowing them to be removed from the server if they're not wanted.
- Repaired some coding in the Anti-Servercrash

Beta 7a:

- Fixed the sark blocking mechanism.
- Removed the selective options from TCCLite after finding a critical weakness in that code.
- Added dictionary attack protection to "Adminlogin" function in 1.09 Game modes


Beta 7:

- Completed TCCLite, a version of AntiTCC v2.2 which shouldn't cause much CPU load.
- Enabled Custom skin support (Must use TCCLite but AntiTCC is optional with the command "pAntiTCC")
- Returned the Sark skin Crash-fix (not sure if it works though)
- Returned Skinswapper and made it more comprehensive.
- Returned the ability to Switchlevel?Game=[NewGameType] when using the 1.09 Game modes (blocked in 1.08 patch)

Beta 6:

- Blocked Speedhacking and a critical server crash bug.
- Blocked a bug where non-admins can change the server map to the next in maplist.
- Blocked malicious client broadcasting (Faking Webadmin/Adminlogin, Subtitle says etc)

- Removed Skin Swapper and the redundant Player class set it used. (~25% less download size)
- Removed 1.09 AntiCheat as a mutator, now controlled through pAntiTcc (or bAntiTCC in beta109.ini)
- Removed Sark Fix. Incompatible with CoAdmin for now. It will return I promise!
- Removed Integrated Coop Mode. Huge download and rarely played. Will be in official release.

Beta 5:

- Added Support for Coop / CTT / HB with CoAdmin & SATools(if enabled) commands and Scoreboards
- Implemented Linux Text filter into RuneServerAdmin for correct-looking WebAdmin when bLinuxServer is enabled.

Beta 4:

- Added my own options to the CoAdmin "pDetails" in-game admin console.
- Added a few CoAdmin game modes, based on the mutator ItemSwap (Instant Gib, Health Wars, Balanced Runes)
- Various performance-related rewrites, bugfixes.

Beta 3a:

- Quick Fix of repeated instances of Event messages displaying in the Rune Console in 1.09 CoAdmin DM and TDM
- 1.09 SANames now works with the Linux fix. I might have fixed another bug in it as well. Time will tell.

Beta 3:

- Corrected Linux Servers not displaying special Symbols
- Removed the RunePlayer clone class (caused a ton of bugs)
- Added a playable Skeleton Warrior Player converted from the "SWarrior" from Rune Co-op
- Included original SWarrior monster class from Rune Co-op by Dark of the Thor's Hammer team
- Corrected several minor console warning bugs.

Beta 1:

- Fixed "Sark Servers Crash RuneHOV" bug
- Fixed BoneClub Animation (Forward AttackC) MultiPlayer glitch.
- Restored "Original" DwarfBattleSword textures (with Blood Texture)
- Contains a custom BattleAxe and WorkSword skin by Sythest
- Balanced Runes, More info on this below.
- Selective Anti-Cheat based off Chakuza's AntiTCC2 *** Updated to v2.2 in beta7 ***
- High-Resolution Rune Menu (Tasuja), also activated 3d Audio option in Options -> Audio
*** Removed in Beta3: 1.07 RunePlayer base with 1.08 features ***
- Routed Skin Swapper through CoAdmin
- Expanded CoAdmin skin bank to include ALL Rune/HOV/1.08 skins, but not customs yet.
- Skin Swapper without CoAdmin DOES support custom skins
- Player Skin names in Server List more closely match what they're named in the selection menu
- Unarmed "Fist" weapon with "HULK!" RunePower
- Included 3 modernized 3d renderers by Chris Dohnal. (Direct3d9 v1.2, OpenGL v1.3, Direct3d8 v1.2)

#############################################################

Credits:

A huge thanks to Zisu for his permission to use his work, and to everyone else who has submitted content.
A big glass of mead for Chris Dohnal, author of the modern renderers: http://www.cwdohnal.com/utglr/
Thanks to Lar for his updated WebAdmin
Thanks to Blitznuckel for his excellent work on Arena.u
Thanks to Tasuja for painting the new menu
Thanks to Sys for consulting and testing Anti-h4x.
Thanks to Chakuza and Enfuego Chavez for the AntiTCC source
Thanks to Zora for written permission to include Nephthys in 1.09
Thanks again to the JuNN horde and Terminus for Runes ideas, and helping test.
Thanks to Firbel for testing the beta6 series so you don't have to get angry at missing .u's.
Thanks to everyone in the ToR servers who dealt with the bugs/constant update downloads, especially the ones who reported bugs without profanity (very few)

############################################################