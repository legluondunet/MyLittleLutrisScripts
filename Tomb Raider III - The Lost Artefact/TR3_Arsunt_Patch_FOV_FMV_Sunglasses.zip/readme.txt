Patched by Arsunt (c) 2017 Tomb Raider Russian Community

- FOV and Aspect Ratio calculated automatically in-game
- New FMV player added. The old one disabled. Supports RPL, MP4 and many other videoformats. FMV sound volume set by in-game Music volume.
- Sunglasses game crash fixed

* Patch is based on Steam EXE file. It is not workaround. It's a clean patch.

mailto:arsunt@gmail.com