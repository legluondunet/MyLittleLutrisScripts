Widescreen fix for Prince of Persia: The Sands of Time ver 1.0.0.1
Created by nemesis2000 <nemesis2000@yandex.ru>
Downloaded from http://ps2wide.net/pc.html

Installation Instructions
=========================================================================

1. Unpack [password: pop]
2. Edit pop.ini
3. Enjoy


Additional Information
=========================================================================

1. Supported exe size: 4�280�320 bytes


References
=========================================================================

1. UPX: the Ultimate Packer for eXecutables <http://upx.sourceforge.net/>