#!/bin/bash

for i in en/*.LFL 
do
echo "traitement du fichier $i"
j=$(basename $i)
#diff -a $i fr/$j > "$j.patch"
patch < $j.patch $i
echo "patch du fichier $i par le fichier $j.patch"
done
