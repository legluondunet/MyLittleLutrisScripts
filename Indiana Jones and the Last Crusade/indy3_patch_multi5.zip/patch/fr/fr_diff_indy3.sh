#!/bin/bash

for i in en/*.LFL 
do
echo "traitement du fichier $i"
j=$(basename $i)
diff -a $i fr/$j > "$j.patch"
echo "creation du fichier $j.patch"
done
