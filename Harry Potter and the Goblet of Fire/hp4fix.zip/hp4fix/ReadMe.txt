Harry Potter and the Goblet of Fire fix

IMPORTANT - You will need to aquire the NO CD exe from the following website for the game you are using this fix for: https://archive.org/details/harry-potter-pc-games-no-cd-cracks

go to show all -> the game you are installing the fix for -> get the no cd for it and copy it into the game directory -> then proceed with this fixes contents.

simply put the d3d9.dll and d3d9.ini into your game folder next to the game exe and your good to go 

you can edit settings in d3d9.ini 

Default for FPS cap is 60 you can change it as you like or uncap with 0

Default for resolution is (1920 x 1080) 

Default for fov is (0) origional 114 you can replace 0 with your number higher than 114 will zoom it out in game.

Default for fpsanimation is 0 which is off or the origional game animation speed, we have tested the game fully and if you set this to 1 or 2 you can play through almost all of the game but one blubotuber is broken so you cant 100% the game.

Default aspect ratio is 1 which is (16:9) 

brought to you by Fix Enhancers 

Team: 

Chip, JokerAlex21, Blankname.

credit to 13AG for d3d9hook base code.

Testers: 

MrDoomStar