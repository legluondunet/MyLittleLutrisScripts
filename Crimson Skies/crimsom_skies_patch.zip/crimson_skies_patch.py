#!/usr/bin/env python3
"""Crimson Skies (2000): patch widescreen resolution and optional Wine ROF fix.

Copyright (C) 2026 legluondunet. GPL-3.0-or-later.
The roffile.dll one-byte fix follows the research by thehack904:
https://github.com/thehack904/CrimsonSkies-Wine-Fix (MIT license).

Third-party notice for the adapted roffile.dll workaround:
MIT License
Copyright (c) 2026 thehack904
Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:
The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

Only the verified widescreen CRIMSON.EXE and verified roffile.dll are supported.
No original game binary is included, downloaded, or decrypted.
"""

import argparse
import hashlib
import os
from pathlib import Path
import stat
import struct
import sys
import tempfile

EXE_SIZE = 2_580_480
EXE_SHA_NORMALIZED = "5578a15ce072d09655be43419829a7530ed6c71fa5a8778fd9d4661770b39d67"
WIDTH_OFF, HEIGHT_OFF = 0x20254B, 0x20254F
FOV60_OFF, FOV80_OFF = 0x20409C, 0x2040A0
FOV60_DEFAULT = bytes.fromhex("92 0a 86 3f")
FOV80_DEFAULT = bytes.fromhex("c2 b8 b2 3f")
DLL_ORIGINAL_SHA = "1bc7b4b1adba1bf6a510e62f93473824c662acbf2a2176087b7b4b85338ba58a"
DLL_RVA = 0x231E
DLL_ORIGINAL_BYTES = bytes.fromhex("80 3e 20 7d 01 46 89 37")
DLL_PATCHED_BYTES = bytes.fromhex("80 3e 20 7d 01 90 89 37")


def digest(data):
    return hashlib.sha256(data).hexdigest()


def file_bytes(path):
    info = path.lstat()  # Avoid following links to other locations.
    if not stat.S_ISREG(info.st_mode):
        raise ValueError(f"Not a regular file (or symlink): {path}")
    return path.read_bytes()


def existing_backup(path):
    try:
        return file_bytes(path)
    except FileNotFoundError:
        return None


def check_exe(data):
    if len(data) != EXE_SIZE or data[:2] != b"MZ":
        raise ValueError("Unsupported CRIMSON.EXE (wrong size or PE signature)")
    pe = struct.unpack_from("<I", data, 0x3C)[0]
    if data[pe:pe + 4] != b"PE\0\0":
        raise ValueError("Invalid executable PE header")
    normalized = bytearray(data)
    struct.pack_into("<II", normalized, WIDTH_OFF, 1920, 1080)
    normalized[FOV60_OFF:FOV60_OFF + 4] = FOV60_DEFAULT
    normalized[FOV80_OFF:FOV80_OFF + 4] = FOV80_DEFAULT
    if digest(normalized) != EXE_SHA_NORMALIZED:
        raise ValueError("Unsupported CRIMSON.EXE build; nothing will be modified")
    return struct.unpack_from("<II", data, WIDTH_OFF)


def exe_with_resolution(original, width, height):
    check_exe(original)
    if not 320 <= width <= 16384 or not 240 <= height <= 16384:
        raise ValueError("Resolution out of supported bounds")
    if not 0.5 <= width / height <= 4.0:
        raise ValueError("Unsupported aspect ratio")
    result = bytearray(original)
    struct.pack_into("<II", result, WIDTH_OFF, width, height)
    # Keep existing FOV parameters unchanged, including user customization.
    check_exe(result)
    return bytes(result)


def rva_to_offset(data, rva):
    if len(data) < 0x40 or data[:2] != b"MZ":
        raise ValueError("roffile.dll is not a PE file")
    pe = struct.unpack_from("<I", data, 0x3C)[0]
    if pe + 24 > len(data) or data[pe:pe + 4] != b"PE\0\0":
        raise ValueError("Invalid roffile.dll PE header")
    sections = struct.unpack_from("<H", data, pe + 6)[0]
    optional_size = struct.unpack_from("<H", data, pe + 20)[0]
    table = pe + 24 + optional_size
    for i in range(sections):
        pos = table + i * 40
        if pos + 40 > len(data):
            raise ValueError("Truncated roffile.dll section table")
        size, va, raw_size, raw = struct.unpack_from("<IIII", data, pos + 8)
        if va <= rva < va + min(size or raw_size, raw_size):
            offset = raw + rva - va
            if offset >= len(data):
                break
            return offset
    raise ValueError("roffile.dll patch RVA not mapped to file data")


def patch_dll(original):
    if digest(original) != DLL_ORIGINAL_SHA:
        raise ValueError("Unknown roffile.dll version (SHA-256 differs): refusing to patch")
    offset = rva_to_offset(original, DLL_RVA)
    if offset < 5 or original[offset - 5:offset + 3] != DLL_ORIGINAL_BYTES:
        raise ValueError("roffile.dll instruction signature differs")
    modified = bytearray(original)
    modified[offset] = 0x90  # INC ESI -> NOP
    if modified[offset - 5:offset + 3] != DLL_PATCHED_BYTES:
        raise ValueError("Internal DLL patch verification failed")
    return bytes(modified)


def get_dll_state(current, backed_up):
    if digest(current) == DLL_ORIGINAL_SHA:
        return "original", patch_dll(current)
    if backed_up is None:
        raise ValueError("Unrecognized/already patched roffile.dll without verified original backup")
    patched = patch_dll(backed_up)  # Validates original SHA and PE RVA.
    if current != patched:
        raise ValueError("Unknown roffile.dll modification: refusing to patch either file")
    return "patched", patched


def child_ignore_case(parent, name):
    if not parent.is_dir():
        return None
    entries = [p for p in parent.iterdir() if p.name.casefold() == name.casefold()]
    if len(entries) > 1:
        raise ValueError(f"Ambiguous entries called {name} in {parent}")
    return entries[0] if entries else None


def default_dll(exe):
    root = exe.parent
    directory = root
    for component in ("GOSDATA", "ASSETS", "BINARIES"):
        directory = child_ignore_case(directory, component)
        if directory is None:
            break
    candidates = []
    if directory is not None:
        dll = child_ignore_case(directory, "roffile.dll")
        if dll is not None:
            candidates.append(dll)
    local = child_ignore_case(root, "roffile.dll")
    if local is not None:
        candidates.append(local)
    if len(candidates) > 1:
        raise ValueError("Multiple roffile.dll files found: choose one with --dll")
    return candidates[0] if candidates else None


def backup_once(path, source, suffix, verifier):
    destination = path.with_name(path.name + suffix)
    existing = existing_backup(destination)
    if existing is not None:
        verifier(existing)
        print(f"Backup preserved: {destination}")
        return
    # The O_EXCL flag refuses existing files, including broken symlinks.
    with destination.open("xb") as f:
        f.write(source)
        f.flush()
        os.fsync(f.fileno())
    try:
        os.chmod(destination, stat.S_IMODE(path.stat().st_mode))
        if file_bytes(destination) != source:
            raise OSError("Backup verification failed")
    except Exception:
        destination.unlink(missing_ok=True)
        raise
    print(f"Backup created: {destination}")


def atomic_write(path, contents):
    mode = stat.S_IMODE(path.stat().st_mode)
    fd, tmpname = tempfile.mkstemp(prefix=f".{path.name}-", suffix=".tmp", dir=path.parent)
    try:
        with os.fdopen(fd, "wb") as f:
            os.fchmod(f.fileno(), mode)
            f.write(contents)
            f.flush()
            os.fsync(f.fileno())
        file_bytes(path)  # Refuse a target that became a symbolic link.
        os.replace(tmpname, path)
        if file_bytes(path) != contents:
            raise OSError(f"Post-write verification failed: {path}")
    finally:
        if os.path.exists(tmpname):
            os.unlink(tmpname)


def main():
    parser = argparse.ArgumentParser(description="Patch verified Crimson Skies EXE resolution and optional roffile.dll Wine fix")
    parser.add_argument("--exe", type=Path, default=Path(__file__).resolve().parent / "CRIMSON.EXE", help="CRIMSON.EXE path (default: next to the script)")
    parser.add_argument("--dll", type=Path, help="Override roffile.dll path (default: auto-detect GOSDATA/ASSETS/BINARIES)")
    parser.add_argument("--width", type=int, default=1920)
    parser.add_argument("--height", type=int, default=1080)
    parser.add_argument("--status", action="store_true", help="Inspect without changing files")
    parser.add_argument("--restore", action="store_true", help="Restore backups, keeping them available")
    args = parser.parse_args()

    exe = args.exe.expanduser().absolute()
    before_exe = file_bytes(exe)
    old_w, old_h = check_exe(before_exe)
    exe_backup_path = exe.with_name(exe.name + ".crimson-original.bak")
    saved_exe = existing_backup(exe_backup_path)
    if saved_exe is not None:
        check_exe(saved_exe)
    dll = args.dll.expanduser().absolute() if args.dll is not None else default_dll(exe)
    if args.dll is not None and not dll.exists():
        raise ValueError(f"Explicit DLL not found: {dll}")
    before_dll = file_bytes(dll) if dll is not None else None
    saved_dll = None
    state = None
    patched_dll = None
    if dll is not None:
        backup = dll.with_name(dll.name + ".before-nul-guard")
        saved_dll = existing_backup(backup)
        if saved_dll is not None:
            patch_dll(saved_dll)
        state, patched_dll = get_dll_state(before_dll, saved_dll)

    print(f"EXE: {exe} | {old_w}x{old_h} | SHA-256 {digest(before_exe)}")
    if dll is None:
        print("DLL: roffile.dll absent; only CRIMSON.EXE will be patched.")
    else:
        print(f"DLL: {dll} | {state} | SHA-256 {digest(before_dll)}")
    if args.status:
        return

    if args.restore:
        if saved_exe is None:
            raise ValueError("Cannot restore: missing verified EXE backup")
        if dll is not None and state == "patched" and saved_dll is None:
            raise ValueError("Cannot restore: missing verified DLL backup")
        if before_exe != saved_exe:
            atomic_write(exe, saved_exe)
            print("EXE restored.")
        if dll is not None and state == "patched":
            atomic_write(dll, saved_dll)
            print("DLL restored.")
        print("Backups retained.")
        return

    after_exe = exe_with_resolution(before_exe, args.width, args.height)
    # All file types, backups and replacements have been validated above.
    if after_exe == before_exe and (dll is None or patched_dll == before_dll):
        print("Already patched. No changes needed.")
        return
    print(f"Target resolution: {args.width}x{args.height}")
    # Backups for both present binaries precede ANY modifications.
    backup_once(exe, before_exe, ".crimson-original.bak", check_exe)
    if dll is not None:
        if saved_dll is None and state == "patched":
            raise ValueError("DLL was already patched but its original backup is missing")
        if saved_dll is None:
            backup_once(dll, before_dll, ".before-nul-guard", patch_dll)
    changed_exe = False
    try:
        if before_exe != after_exe:
            atomic_write(exe, after_exe)
            changed_exe = True
            print("EXE resolution patched.")
        if dll is not None and before_dll != patched_dll:
            atomic_write(dll, patched_dll)
            print("roffile.dll NUL-guard patched (RVA 0x231E, INC ESI -> NOP).")
    except Exception:
        if changed_exe:
            try:
                atomic_write(exe, before_exe)
                print("EXE rolled back after DLL write failure.", file=sys.stderr)
            except Exception as rollback_error:
                print(f"WARNING: EXE rollback failed: {rollback_error}", file=sys.stderr)
        raise
    print("Completed. Original backups retained; restart the game for testing.")


if __name__ == "__main__":
    try:
        main()
    except (OSError, ValueError, struct.error) as error:
        print(f"ERROR: {error}", file=sys.stderr)
        sys.exit(1)
