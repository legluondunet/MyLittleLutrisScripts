#!/usr/bin/env python3
"""Change only the resolution of the verified Crimson Skies (2000) CRIMSON.EXE.

Copyright (C) 2026 legluondunet. SPDX-License-Identifier: GPL-3.0-or-later.
No game binary is included or downloaded. No DLL is read or modified.
"""

import argparse
import hashlib
import os
from pathlib import Path
import stat
import struct
import sys
import tempfile

# Verified executable supplied with the original resolution patcher.
EXE_SIZE = 2_580_480
REFERENCE_SHA256 = "5578a15ce072d09655be43419829a7530ed6c71fa5a8778fd9d4661770b39d67"
WIDTH_OFFSET = 0x20254B
HEIGHT_OFFSET = 0x20254F
FOV60_OFFSET = 0x20409C
FOV80_OFFSET = 0x2040A0
REFERENCE_FOV60 = bytes.fromhex("92 0a 86 3f")
REFERENCE_FOV80 = bytes.fromhex("c2 b8 b2 3f")
BACKUP_SUFFIX = ".crimson-original.bak"  # Compatible with the previous script.


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def read_regular_file(path):
    """Reject symbolic links, even if they point to regular files."""
    mode = path.lstat().st_mode
    if not stat.S_ISREG(mode):
        raise ValueError(f"Not a regular file: {path}")
    return path.read_bytes()


def read_backup(path):
    try:
        return read_regular_file(path)
    except FileNotFoundError:
        return None


def resolution(data):
    """Validate this exact EXE build, allowing changes only to resolution/FOV."""
    if len(data) != EXE_SIZE or data[:2] != b"MZ":
        raise ValueError("Unsupported CRIMSON.EXE (size or DOS signature differs)")
    pe_offset = struct.unpack_from("<I", data, 0x3C)[0]
    if data[pe_offset:pe_offset + 4] != b"PE\0\0":
        raise ValueError("Invalid CRIMSON.EXE PE header")

    normalized = bytearray(data)
    struct.pack_into("<II", normalized, WIDTH_OFFSET, 1920, 1080)
    normalized[FOV60_OFFSET:FOV60_OFFSET + 4] = REFERENCE_FOV60
    normalized[FOV80_OFFSET:FOV80_OFFSET + 4] = REFERENCE_FOV80
    if sha256(normalized) != REFERENCE_SHA256:
        raise ValueError("Unrecognized CRIMSON.EXE build; no file modified")
    return struct.unpack_from("<II", data, WIDTH_OFFSET)


def with_resolution(data, width, height):
    resolution(data)
    if not (320 <= width <= 16384 and 240 <= height <= 16384):
        raise ValueError("Resolution outside the supported range")
    if not 0.5 <= width / height <= 4.0:
        raise ValueError("Unsupported aspect ratio")
    updated = bytearray(data)
    struct.pack_into("<II", updated, WIDTH_OFFSET, width, height)
    resolution(updated)  # Check that nothing else changed.
    return bytes(updated)


def create_backup_once(path, backup, original):
    if read_backup(backup) is not None:
        return  # Caller already verified the preserved backup.
    # 'xb' prevents overwriting any existing backup (including a symlink).
    with backup.open("xb") as f:
        f.write(original)
        f.flush()
        os.fsync(f.fileno())
    try:
        os.chmod(backup, stat.S_IMODE(path.stat().st_mode))
        if read_regular_file(backup) != original:
            raise OSError("Backup verification failed")
    except Exception:
        backup.unlink(missing_ok=True)
        raise
    print(f"Original backup created: {backup}")


def replace_atomically(path, data):
    """Replace an EXE in place without ever using a partially-written file."""
    mode = stat.S_IMODE(path.lstat().st_mode)
    fd, tempname = tempfile.mkstemp(prefix=f".{path.name}-", suffix=".tmp", dir=path.parent)
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(data)
            f.flush()
            os.fsync(f.fileno())
        os.chmod(tempname, mode)
        read_regular_file(path)  # Check the target is still not a symlink.
        os.replace(tempname, path)
        if read_regular_file(path) != data:
            raise OSError("Post-write verification failed")
    finally:
        if os.path.exists(tempname):
            os.unlink(tempname)


def main():
    parser = argparse.ArgumentParser(description="Change only the resolution of CRIMSON.EXE")
    parser.add_argument("--exe", type=Path,
                        default=Path(__file__).resolve().parent / "CRIMSON.EXE",
                        help="EXE to patch (default: CRIMSON.EXE next to this script)")
    parser.add_argument("--width", type=int, default=1920)
    parser.add_argument("--height", type=int, default=1080)
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--status", action="store_true", help="Show current resolution without changing anything")
    mode.add_argument("--restore", action="store_true", help="Restore the original EXE from its backup")
    args = parser.parse_args()

    exe = args.exe.expanduser().absolute()
    current = read_regular_file(exe)
    old_width, old_height = resolution(current)
    backup = exe.with_name(exe.name + BACKUP_SUFFIX)
    saved = read_backup(backup)
    if saved is not None:
        resolution(saved)  # Never trust an existing backup blindly.

    print(f"Executable: {exe}")
    print(f"Current resolution: {old_width} x {old_height}")
    print(f"Backup: {backup} ({'present' if saved is not None else 'absent'})")
    if args.status:
        return

    if args.restore:
        if saved is None:
            raise ValueError("Cannot restore: original EXE backup is missing")
        if current != saved:
            replace_atomically(exe, saved)
            print("Original CRIMSON.EXE restored.")
        else:
            print("CRIMSON.EXE already matches its backup.")
        return

    updated = with_resolution(current, args.width, args.height)
    if current == updated:
        print("Resolution already correct; no changes made.")
        return

    create_backup_once(exe, backup, current)
    replace_atomically(exe, updated)
    print(f"Resolution changed: {old_width} x {old_height} -> {args.width} x {args.height}")
    print("Original backup preserved. No DLL touched.")


if __name__ == "__main__":
    try:
        main()
    except (OSError, ValueError, struct.error) as error:
        print(f"ERROR: {error}", file=sys.stderr)
        sys.exit(1)
