JK2 FX MOD 3.0 - rev. 2020, HellBaron - May the 4th, 2020

Installation:
Copy "assets8_Fx" and autoexec.cfg files in "base" folder into your Jedi Outcast folder. 
If you use a WIDESCREEN monitor you need to copy "jk2gamex86.dll" file in GameData folder, this fixes the FOV of weapons in 16:9 resolutions.
FX is NOW for single and multiplayer modes.

Included "HD loading screens" by ND (Quiet Bob @ PCGW), "GGFontsHQ v1.0" by Grab and Stormtrooper model by Haps.(thank you a lot for your works!)

- For widescreen monitor, you can write them on console or add in the autoexec:
seta r_mode "-1"
seta r_customheight "1080"  or your desktop setting (if lower or higher)
seta r_customwidth "1920"   or your desktop setting (if lower or higher)
seta cg_fov "100"           (80 is default, recommended 100 for fullHD resolution)

Then write vid_restart, the game will restart the map (the game will be in pause) to set up new settings. Enjoy!

ALWAYS RUN THE GAME AS ADMINISTRATOR!

HellBaron - May the 4th, 2020

Update May the 4th, 2020:
Fixed many shader surfaces.
New effects for all skin SP/MP, new red/blue skin for Stormtrooper model by Haps.
FX mod now works for both game modes with no problems.
Removed "special effects v1 mod" for some limitations of the engine, especially in online matches.

Update October 21 2019:

-Renamed the main pk3 file.
-Fixed some shader surfaces.
-Fixed autoexec for saber autoblocking.

Update December 2 2019:

-Merged and fixed "special effects v1 mod" effects, optimized. (by TK-231, THANK YOU!!!)
-Fixed some shader surfaces.
-Fixed autoexec for many adjustments.

Update February 1 2020:

-Optimized "special effects v1 mod" effects.
-Many fixes and adjustements.