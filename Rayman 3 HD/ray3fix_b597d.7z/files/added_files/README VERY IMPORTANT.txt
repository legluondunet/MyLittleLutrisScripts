*First thing you should do before installing this patch is to UNINSTALL Better Rayman 3 if you have that patch installed, as it's no longer needed with this patch and it will most likely cause conflicts.

*Second, after you've copied/installed the files over to your Rayman 3 installation, go to the game's configuration file and disable Transform & Lighting (change TnL = 1 to 0 in Ubi.ini to be more specific).
This is needed to ensure compatibility between dgVoodoo and Better Rayman 3, don't worry though the game looks exactly the same with that option disabled.