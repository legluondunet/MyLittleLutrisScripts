HP8 (Harry Potter and the Deathly Hallows part 2 NON - EA App Version) PC FIX (by Fix Enhancers): 

IMPORTANT - You will need to aquire the NO CD exe from the following website for the game you are using this fix for: https://archive.org/details/harry-potter-pc-games-no-cd-cracks

go to show all -> the game you are installing the fix for -> get the no cd for it and copy it into the game directory -> then proceed with this fixes contents.

simply put the d3d9.dll and d3d9.ini and fps.dll into your game folder next to the game exe and your good to go (this will only work with the hp8.exe and rld.dll nocd from archive.org and not any other.)

Default for FPS is 60 (leave it at 60 we have done alot of testing and the game is broken past 60fps.)

Default for fov is 1 (on) you can turn it off in the ini with fov = 0 (off) this will set FOV to its default value. this setting is only on or off in this fix. 

brought to you by Fix Enhancers 

Team: 

Chip, JokerAlex21, Blankname.

credit to 13AG for d3d9hook base code.